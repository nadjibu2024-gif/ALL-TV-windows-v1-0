'use strict';
// All-sites menu, Cast panel and the Kids Space profile picker
(function () {
  const layers = document.getElementById('layers');
  const S = window.ALLTV_SITES;
  const el = (tag, cls, html) => { const e = document.createElement(tag); if (cls) e.className = cls; if (html != null) e.innerHTML = html; return e; };
  const esc = (s) => String(s).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
  const open = new Set();
  function addLayer(node, onEsc) {
    layers.appendChild(node);
    const h = (e) => { if (e.key === 'Escape') { e.preventDefault(); e.stopPropagation(); close(); } };
    function close() { document.removeEventListener('keydown', h, true); node.remove(); open.delete(close); if (onEsc) onEsc(); }
    document.addEventListener('keydown', h, true); open.add(close);
    return close;
  }

  function menu(onPick) {
    const root = el('div', 'layer menu');
    root.appendChild(el('h1', null, 'كل المواقع'));
    const x = el('button', 'xbtn', '&#10005;'); root.appendChild(x);
    const grid = el('div', 'grid scroll');
    S.forEach((s, i) => {
      const c = el('button', 'mcell'); c.style.setProperty('--c', s.color);
      c.innerHTML = `<img src="${s.tile}" alt=""><span>${esc(s.name)}</span>`;
      c.onclick = () => { close(); onPick(i); };
      grid.appendChild(c);
    });
    root.appendChild(grid);
    const close = addLayer(root); x.onclick = close;
    const cur = grid.children[window.__selIndex || 0]; if (cur) { cur.focus(); cur.scrollIntoView({ block: 'center' }); }
  }

  function cast() {
    const root = el('div', 'layer modal'); const card = el('div', 'card');
    card.innerHTML = `<h2>البث إلى شاشة</h2><p>اختر الجهاز لعرض التطبيق عليه بالصوت والصورة (Miracast / Smart TV / Chromecast عبر ويندوز).</p>
<p>١) اضغط «بحث عن الأجهزة» ثم اختر التلفاز من القائمة.<br>٢) عند الاتصال يظهر التطبيق على الشاشة بالصوت والصورة.</p>`;
    const row = el('div', 'row');
    const b1 = el('button', 'btn primary', 'بحث عن الأجهزة (Win + K)');
    const b2 = el('button', 'btn soft2', 'خيارات العرض (Win + P)');
    const b3 = el('button', 'btn soft2', 'إعدادات الأجهزة اللاسلكية');
    const b4 = el('button', 'btn soft2', 'إغلاق');
    b1.onclick = () => window.alltv.cast('connect'); b2.onclick = () => window.alltv.cast('project'); b3.onclick = () => window.alltv.cast('settings');
    row.append(b1, b2, b3, b4); card.appendChild(row); root.appendChild(card);
    const close = addLayer(root); b4.onclick = close; root.addEventListener('mousedown', (e) => { if (e.target === root) close(); }); b1.focus();
  }

  const KIDS = [
    { key: 'children', name: 'Children', url: 'https://kidoodle.tv/hub/DiscoveryHome?source=sidebar', c: ['#FF7AC8', '#C71E86'] },
    { key: 'cocomelon', name: 'Cocomelon', url: 'https://cno.to/show/209710-cocomelon-lane', c: ['#B57CFF', '#5B22C9'] },
    { key: 'kidstube', name: 'Kids Tube', url: 'https://www.kids-tube.com/', c: ['#FFB04A', '#D9560B'] },
    { key: 'toongoggles', name: 'ToonGoggles', url: 'https://www.toongoggles.com/', c: ['#FF6B6B', '#B3161F'] },
    { key: 'kidsarabic', name: 'Kids Arabic', url: 'https://nahlaaa.com/', c: ['#4FE3C1', '#0B7A66'] },
  ];
  function kids(onPick) {
    const root = el('div', 'layer kids'); const col = el('div', 'col'); col.style.cssText = 'position:absolute;inset:0;justify-content:center';
    col.appendChild(el('div', 'brand', 'KIDS SPACE')); col.appendChild(el('div', 'gtitle', "Who's Watching?"));
    const row = el('div', 'prow'); row.style.cssText = 'margin-top:30px;flex-wrap:wrap';
    KIDS.forEach((k, i) => {
      const slot = el('div', 'pslot'); slot.style.setProperty('--ps', '120px'); slot.style.animationDelay = (80 + i * 70) + 'ms';
      const av = el('button', 'pav'); av.innerHTML = Icons.avatar(k.c); av.onclick = () => { close(); onPick(k); };
      slot.append(av, el('div', 'lbl', k.name)); row.appendChild(slot); if (!i) av.setAttribute('data-f', '1');
    });
    col.appendChild(row); root.appendChild(col);
    const back = el('button', 'backchip', '&#8592;&nbsp; Back'); root.appendChild(back);
    const close = addLayer(root); back.onclick = close; root.querySelector('[data-f]').focus();
  }

  window.Panels = { menu, cast, kids, closeAll() { [...open].forEach((f) => f()); } };
})();
