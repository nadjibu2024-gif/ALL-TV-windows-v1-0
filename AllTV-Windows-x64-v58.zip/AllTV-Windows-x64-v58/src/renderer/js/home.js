'use strict';
// Home screen: icon strip (Google TV style), round buttons, profile chip, opening sites, site bar
(function () {
  const S = window.ALLTV_SITES, N = S.length, api = window.alltv;
  const $ = (id) => document.getElementById(id);
  const strip = $('strip'), tiles = [];
  let sel = 0, pos = 0, posAnim = null, opening = false, siteOpen = false, curSite = null, adsOn = true;
  let item = 200, spacing = 170, selGap = 28, lift = 14, originY = 0, W = 0, H = 0;

  // ---------- strip ----------
  S.forEach((s, i) => {
    const t = document.createElement('button'); t.className = 'tile'; t.style.setProperty('--c', s.color); t.title = s.name; t.setAttribute('aria-label', s.name);
    t.innerHTML = `<div class="glow"></div><div class="glow2"></div><div class="face"><img src="${s.tile}" alt="" draggable="false"></div><div class="edge"></div><div class="shine"><i></i></div><div class="ring"></div>`;
    const im = t.querySelector('img'); im.onload = () => { if (im.naturalWidth) t.style.setProperty('--ar', (im.naturalWidth / im.naturalHeight).toFixed(4)); };
    t.onclick = () => { if (dragMoved) return; onSiteClick(i); };
    strip.appendChild(t); tiles.push(t);
  });
  function compute() {
    W = strip.clientWidth; H = strip.clientHeight;
    if (H > W) { item = Math.min(.36 * W, .22 * H); originY = H - item - .12 * H; } else { item = Math.min(.19 * W, .36 * H); originY = H - item - .02 * H; }
    spacing = item * .86; selGap = item * .14; lift = item * .07;
    strip.style.setProperty('--item', item + 'px');
    for (const t of tiles) { t.style.width = item + 'px'; t.style.height = item + 'px'; }
    apply();
  }
  function apply() {
    const left = (W - item) / 2;
    for (let i = 0; i < N; i++) {
      const t = tiles[i], d = i - pos, ad = Math.abs(d), sign = d < 0 ? -1 : 1;
      const x = left + d * spacing + sign * Math.min(ad, 1) * selGap, near = Math.max(0, 1 - ad);
      if (x < -item * 1.2 || x > W + item * .2) { t.style.display = 'none'; continue; }
      t.style.display = ''; t.style.transform = `translate(${x.toFixed(1)}px,${(originY - lift * near).toFixed(1)}px)`; t.style.opacity = (1 - .5 * Math.min(ad, 2) / 2).toFixed(3);
      t.style.zIndex = String(100 - Math.round(ad * 10));
    }
  }
  function animateTo(i) {
    if (posAnim) cancelAnimationFrame(posAnim);
    const from = pos, to = i, t0 = performance.now(), dur = 380, tn = 0.9;
    if (Math.abs(from - to) < .001) { pos = to; apply(); return; }
    const ov = (x) => { x -= 1; return x * x * ((tn + 1) * x + tn) + 1; };
    const step = (now) => { const f = Math.min(1, (now - t0) / dur); pos = from + (to - from) * ov(f); apply(); if (f < 1) posAnim = requestAnimationFrame(step); else posAnim = null; };
    posAnim = requestAnimationFrame(step);
  }
  function select(i, animate) {
    i = Math.max(0, Math.min(N - 1, i)); const changed = i !== sel; sel = i; window.__selIndex = i;
    tiles.forEach((t, k) => t.classList.toggle('sel', k === i));
    Hero.setIndex(i, animate && changed);
    if (animate && changed) Sound.hover();
    Prefs.set('lastName', S[i].name);
    if (animate) animateTo(i); else { pos = i; apply(); }
  }

  // drag / wheel / keys
  let dragging = false, dragMoved = false, downX = 0, downPos = 0;
  strip.addEventListener('pointerdown', (e) => { dragging = true; dragMoved = false; downX = e.clientX; downPos = pos; if (posAnim) { cancelAnimationFrame(posAnim); posAnim = null; } });
  window.addEventListener('pointermove', (e) => {
    if (!dragging) return; const dx = e.clientX - downX;
    if (!dragMoved && Math.abs(dx) > 6) dragMoved = true;
    if (dragMoved) { pos = Math.max(-.3, Math.min(N - 1 + .3, downPos - dx / spacing)); apply(); const near = Math.round(Math.max(0, Math.min(N - 1, pos))); if (near !== sel) { sel = near; window.__selIndex = near; tiles.forEach((t, k) => t.classList.toggle('sel', k === near)); Hero.setIndex(near, true); Sound.hover(); Prefs.set('lastName', S[near].name); } }
  });
  window.addEventListener('pointerup', () => { if (!dragging) return; dragging = false; if (dragMoved) { animateTo(sel); setTimeout(() => { dragMoved = false; }, 30); } });
  let wheelAt = 0;
  strip.addEventListener('wheel', (e) => { e.preventDefault(); const n = performance.now(); if (n - wheelAt < 120) return; wheelAt = n; const d = Math.abs(e.deltaX) > Math.abs(e.deltaY) ? e.deltaX : e.deltaY; if (d) select(sel + (d > 0 ? 1 : -1), true); }, { passive: false });
  const homeVisible = () => !siteOpen && !document.getElementById('layers').children.length;
  document.addEventListener('keydown', (e) => {
    if (e.key === 'F11') { e.preventDefault(); api.toggleFullscreen(); return; }
    if (!homeVisible()) return;
    if (e.key === 'ArrowRight' || e.key === 'ArrowDown') { e.preventDefault(); select(sel + 1, true); }
    else if (e.key === 'ArrowLeft' || e.key === 'ArrowUp') { e.preventDefault(); select(sel - 1, true); }
    else if (e.key === 'Home') select(0, true); else if (e.key === 'End') select(N - 1, true);
    else if (e.key === 'Enter' || e.key === ' ') { if (document.activeElement && document.activeElement.classList.contains('rbtn')) return; e.preventDefault(); onSiteClick(sel); }
    else if (e.key === 'm' || e.key === 'M') Panels.menu(openByIndex);
  });

  // ---------- opening ----------
  function onSiteClick(i) {
    if (opening) return; opening = true;
    if (i !== sel) select(i, true);
    Prefs.set('lastName', S[i].name); Sound.open();
    const t = tiles[i]; t.classList.remove('burst'); void t.offsetWidth; t.classList.add('burst');
    setTimeout(() => { openSite(S[i]); opening = false; }, 300);
  }
  const openByIndex = (i) => { if (tiles[i]) onSiteClick(i); };

  function openSite(s) {
    const u = s.url;
    if (u === 'kidsspace://') { Panels.kids((k) => launch({ name: 'Kids Space', url: k.url })); return; }
    if (u === 'tvworld://') { enterFull(); TvLists.open('ara', exitFull); return; }
    if (u === 'freetv://') { enterFull(); TvLists.open('free', exitFull); return; }
    if (u.indexOf('downloader://') === 0) { launch({ name: s.name, url: 'https://elephtv.pro/' }); return; }
    launch({ name: s.name, url: u });
  }
  function enterFull() { document.body.classList.add('overlay-open'); }
  function exitFull() { document.body.classList.remove('overlay-open'); }

  function launch(req) {
    siteOpen = true; curSite = req; document.body.classList.add('site-open');
    $('siteBar').hidden = false; $('sbTitle').textContent = req.name; $('sbLoad').classList.add('on'); $('sbBack').disabled = false;
    api.openSite(req);
  }
  function closeSiteUi() {
    siteOpen = false; curSite = null; document.body.classList.remove('site-open'); $('siteBar').hidden = true; $('sbLoad').classList.remove('on');
    setTimeout(() => tiles[sel] && tiles[sel].focus({ preventScroll: true }), 50);
  }
  function goHome() { api.closeSite(); closeSiteUi(); }
  async function goBack() { const ok = await api.siteBack(); if (!ok) goHome(); }

  $('sbBack').onclick = goBack; $('sbHome').onclick = goHome; $('sbReload').onclick = () => api.siteReload();
  $('sbFull').onclick = () => api.toggleFullscreen(); $('sbCast').onclick = () => Panels.cast();
  $('sbCast').innerHTML = Icons.glyph.cast('#FF5CC0');
  $('sbAds').onclick = () => { adsOn = !adsOn; $('sbAds').classList.toggle('off', !adsOn); api.setAds(adsOn); };
  api.onSiteState((st) => {
    if (!siteOpen) return;
    if (st.title) $('sbTitle').textContent = st.title;
    if (st.loading != null) $('sbLoad').classList.toggle('on', !!st.loading);
  });
  api.onSiteCmd((cmd) => { if (!siteOpen) return; if (cmd === 'back') goBack(); else if (cmd === 'home') goHome(); });
  api.onSiteClosed(() => { if (siteOpen) closeSiteUi(); });

  // ---------- buttons ----------
  $('btnBack').innerHTML = Icons.glyph.back(); $('btnMenu').innerHTML = Icons.glyph.menu(); $('btnNews').innerHTML = Icons.glyph.news(); $('btnCast').innerHTML = Icons.glyph.cast('#fff');
  $('btnBack').onclick = () => switchProfile(); $('btnMenu').onclick = () => Panels.menu(openByIndex);
  $('btnNews').onclick = () => Markets.open(); $('btnCast').onclick = () => Panels.cast();
  $('btnProfile').onclick = () => switchProfile();
  function updateChip() {
    const p = Profiles.getActive(), c = $('btnProfile');
    if (!p) { c.hidden = true; return; }
    c.hidden = false; c.style.setProperty('--pc', Profiles.PALETTE[p.color][0]);
    c.innerHTML = `<span class="av">${Icons.avatar(p.color)}</span><span></span>`; c.lastChild.textContent = p.name;
    c.querySelector('.av').style.cssText = 'width:34px;height:34px;display:block;flex:none';
  }
  function switchProfile() { Login.show({ cancellable: !!Profiles.getActive(), onEntered: () => updateChip(), onCancel: () => {} }); }

  // ---------- live pictures of the real home pages (7 sites, refreshed every 6 h) ----------
  const LIVE = ['1Flex', 'Movy', 'OnDemand', 'Movix', 'Dulo', 'Spacedom', 'Algeria TV'];
  async function liveInit() {
    try {
      const list = await api.snapList(); const haveNow = {};
      for (const f of list) { const i = S.findIndex((s) => s.name === f.name); if (i < 0 || !LIVE.includes(f.name)) continue; Hero.setLive(i, f.file, f.portrait); if ((H > W) === f.portrait) haveNow[f.name] = f.mtime; }
      api.onSnap((r) => { const i = S.findIndex((s) => s.name === r.name); if (i >= 0) Hero.setLive(i, r.file, r.portrait); });
      const refresh = () => {
        if (siteOpen || document.getElementById('layers').children.length) return;
        const portrait = H > W, need = LIVE.filter((n) => !haveNow[n] || Date.now() - haveNow[n] > 6 * 3600 * 1000);
        if (need.length) { api.snapStart(need, portrait); need.forEach((n) => { haveNow[n] = Date.now(); }); }
      };
      setTimeout(refresh, 3500); setInterval(refresh, 30 * 60 * 1000);
    } catch (e) { /* live pictures are optional */ }
  }

  window.addEventListener('resize', compute);
  window.Home = { select, updateChip, switchProfile, compute, liveInit };
  compute();
  // remember the last site
  const last = Prefs.get('lastName', null); let start = 0; if (last) { const k = S.findIndex((s) => s.name === last); if (k >= 0) start = k; }
  select(start, false);
})();
