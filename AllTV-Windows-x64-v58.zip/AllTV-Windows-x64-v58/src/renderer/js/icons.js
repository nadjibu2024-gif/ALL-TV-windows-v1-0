'use strict';
// Vector drawings that match the pictures drawn in code by the Android app
(function () {
  let uid = 0;
  const P = () => window.Profiles.PALETTE;

  // Netflix style profile square: glossy colour, smiling face (or "+" square)
  function avatar(colorIdx, opts) {
    opts = opts || {};
    const id = 'a' + (++uid);
    const c = Array.isArray(colorIdx) ? colorIdx : P()[Math.max(0, Math.min(7, colorIdx | 0))];
    if (opts.plus) {
      return `<svg viewBox="0 0 100 100" xmlns="http://www.w3.org/2000/svg"><rect x="0" y="0" width="100" height="100" rx="10" fill="#161616"/>
<rect class="pf" x="1.75" y="1.75" width="96.5" height="96.5" rx="10" fill="none" stroke="#4A4A4A" stroke-width="2.4"/>
<g class="pp" stroke="#B5B5B5" stroke-width="4.5" stroke-linecap="round"><line x1="33" y1="50" x2="67" y2="50"/><line x1="50" y1="33" x2="50" y2="67"/></g></svg>`;
    }
    const pencil = opts.edit ? `<rect width="100" height="100" rx="10" fill="rgba(0,0,0,.6)"/><path d="M30 70 L48.5 51.5 L51.5 48.5 L70 30" fill="none" stroke="#fff" stroke-width="7.5" stroke-linecap="round" stroke-linejoin="round"/>` : '';
    return `<svg viewBox="0 0 100 100" xmlns="http://www.w3.org/2000/svg"><defs>
<linearGradient id="${id}b" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="${c[0]}"/><stop offset="1" stop-color="${c[1]}"/></linearGradient>
<radialGradient id="${id}r" gradientUnits="userSpaceOnUse" cx="28" cy="18" r="85"><stop offset="0" stop-color="#fff" stop-opacity=".25"/><stop offset="1" stop-color="#fff" stop-opacity="0"/></radialGradient>
<linearGradient id="${id}s" x1="0" y1="0" x2="0" y2="55" gradientUnits="userSpaceOnUse"><stop offset="0" stop-color="#fff" stop-opacity=".18"/><stop offset="1" stop-color="#fff" stop-opacity="0"/></linearGradient></defs>
<rect width="100" height="100" rx="10" fill="url(#${id}b)"/><rect width="100" height="100" rx="10" fill="url(#${id}r)"/><rect width="100" height="100" rx="10" fill="url(#${id}s)"/>
<ellipse cx="30" cy="45" rx="8.5" ry="15" fill="#fff"/><ellipse cx="70" cy="45" rx="8.5" ry="15" fill="#fff"/>
<path d="M75.96 66.24 A28 22 0 0 1 24.04 66.24" fill="none" stroke="#fff" stroke-width="5.8" stroke-linecap="round"/>${pencil}</svg>`;
  }

  const ring = (s) => `<circle cx="23" cy="23" r="21.2" fill="rgba(0,0,0,0)" stroke="none"/>`;

  // round button glyphs (46 x 46 box, same proportions as the Android drawing code)
  const glyph = {
    cast(color) {
      color = color || '#fff';
      const u = 27.6, l = 23 - u * .4, r = 23 + u * .4, t = 23 - u * .3, b = 23 + u * .3;
      const sw = Math.max(2, u * .075).toFixed(2);
      const arc = (k) => { const rr = u * (.15 + .17 * k); return `M${l.toFixed(2)} ${(b - rr).toFixed(2)} A${rr.toFixed(2)} ${rr.toFixed(2)} 0 0 1 ${(l + rr).toFixed(2)} ${b.toFixed(2)}`; };
      return `<svg viewBox="0 0 46 46" xmlns="http://www.w3.org/2000/svg" fill="none" stroke="${color}" stroke-width="${sw}" stroke-linecap="butt" stroke-linejoin="miter">
<path d="M${l.toFixed(2)} ${(23 - u * .14).toFixed(2)} L${l.toFixed(2)} ${t.toFixed(2)} L${r.toFixed(2)} ${t.toFixed(2)} L${r.toFixed(2)} ${b.toFixed(2)} L${(23 - u * .06).toFixed(2)} ${b.toFixed(2)}"/>
<path d="${arc(1)}"/><path d="${arc(2)}"/><circle cx="${(l + u * .03).toFixed(2)}" cy="${(b - u * .03).toFixed(2)}" r="${(u * .05).toFixed(2)}" fill="${color}" stroke="none"/></svg>`;
    },
    news() {
      const s = 46, barW = s * .1, gap = s * .05, base = 23 + s * .2, hs = [s * .16, s * .27, s * .38];
      const sx = 23 - (barW * 3 + gap * 2) / 2;
      let bars = '';
      for (let i = 0; i < 3; i++) bars += `<rect x="${(sx + i * (barW + gap)).toFixed(2)}" y="${(base - hs[i]).toFixed(2)}" width="${barW.toFixed(2)}" height="${hs[i].toFixed(2)}" rx="${(s * .025).toFixed(2)}" fill="#fff"/>`;
      const pts = [[sx - s * .02, base - s * .22], [23 - s * .02, base - s * .34], [23 + s * .1, base - s * .28], [sx + barW * 3 + gap * 2 + s * .02, base - s * .46]];
      return `<svg viewBox="0 0 46 46" xmlns="http://www.w3.org/2000/svg">${bars}<polyline points="${pts.map((p) => p[0].toFixed(2) + ',' + p[1].toFixed(2)).join(' ')}" fill="none" stroke="#4ADE80" stroke-width="${(s * .045).toFixed(2)}" stroke-linecap="round" stroke-linejoin="round"/></svg>`;
    },
    menu() {
      const s = 46, cell = s * .15, gap = s * .06, corner = s * .035;
      let q = '';
      for (let r = 0; r < 2; r++) for (let c = 0; c < 2; c++) q += `<rect x="${(23 - gap / 2 - cell + c * (cell + gap)).toFixed(2)}" y="${(23 - gap / 2 - cell + r * (cell + gap)).toFixed(2)}" width="${cell.toFixed(2)}" height="${cell.toFixed(2)}" rx="${corner.toFixed(2)}" fill="#fff"/>`;
      return `<svg viewBox="0 0 46 46" xmlns="http://www.w3.org/2000/svg">${q}</svg>`;
    },
    back() {
      const s = 46, len = s * .2, head = s * .13;
      return `<svg viewBox="0 0 46 46" xmlns="http://www.w3.org/2000/svg" fill="none" stroke="#fff" stroke-width="${(s * .075).toFixed(2)}" stroke-linecap="round" stroke-linejoin="round"><path d="M${23 + len} 23 L${23 - len} 23 M${(23 - len + head).toFixed(2)} ${23 - head} L${23 - len} 23 L${(23 - len + head).toFixed(2)} ${23 + head}"/></svg>`;
    },
  };

  window.Icons = { avatar, glyph, ring };
})();
