'use strict';
// Sounds of the app (same two sounds as Android: icon change = hover, opening a site = open)
(function () {
  const files = { hover: 'assets/sounds/hover.wav', open: 'assets/sounds/open.wav' };
  const pool = {};
  let last = 0;
  for (const k of Object.keys(files)) { const a = new Audio(files[k]); a.preload = 'auto'; pool[k] = a; }
  function play(name, vol) {
    const base = pool[name]; if (!base) return;
    try {
      const a = base.cloneNode(); a.volume = Math.max(0, Math.min(1, vol == null ? 1 : vol));
      const p = a.play(); if (p && p.catch) p.catch(() => {});
    } catch (e) { /* ignore */ }
  }
  window.Sound = {
    hover() { const n = performance.now(); if (n - last < 70) return; last = n; play('hover', 0.55); },
    open() { play('open', 1); },
    play,
  };
})();
