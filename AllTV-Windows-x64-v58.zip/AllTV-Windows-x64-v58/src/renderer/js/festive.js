'use strict';
// Snow, maple leaves 🍁, falling stars, string of coloured light bulbs and the hanging crescent moon.
// Direct port of FestiveOverlay.java (same numbers, speeds, colours and shapes). Never takes a mouse click.
(function () {
  const SNOW = 46, LEAVES = 12, STARS = 9, MOON_SS = 2;
  const LEAF_COLORS = ['#E8541E', '#FF8A1F', '#C62828', '#FFB300'];
  const BULB_COLORS = ['#FF3B3B', '#FF9A1F', '#FFE23B', '#38E86B', '#2FD9FF', '#4D7CFF', '#B35CFF', '#FF4FB8'];
  const TOTAL = SNOW + LEAVES + STARS;

  // seeded random (java.util.Random(7) look-alike is not needed, any steady generator will do)
  let seed = 7;
  const rnd = () => { seed = (seed * 1664525 + 1013904223) >>> 0; return seed / 4294967296; };
  const rint = (n) => Math.floor(rnd() * n);

  const cv = document.getElementById('festive');
  const ctx = cv.getContext('2d');
  let W = 0, H = 0, dpr = 1, d = 1;

  const px = new Float32Array(TOTAL), py = new Float32Array(TOTAL), speed = new Float32Array(TOTAL), size = new Float32Array(TOTAL);
  const swayAmp = new Float32Array(TOTAL), swayPhase = new Float32Array(TOTAL), swaySpeed = new Float32Array(TOTAL);
  const rot = new Float32Array(TOTAL), rotSpeed = new Float32Array(TOTAL), flipPhase = new Float32Array(TOTAL);
  const kind = new Uint8Array(TOTAL), sub = new Uint8Array(TOTAL);
  for (let i = 0; i < TOTAL; i++) kind[i] = i < SNOW ? 0 : (i < SNOW + LEAVES ? 1 : 2);

  let leafSpr = [], flakeSpr = [], starSpr = [], haloSpr = [], moonSpr = null, moonHalo = null;
  let wirePath = null, bx = [], by = [], bcol = [], moonAx = 0, moonAy = 0, moonR = 0, moonL = 0, ready = false;
  let clock = 0, last = 0;

  const mk = (w, h) => { const c = document.createElement('canvas'); c.width = Math.max(1, Math.ceil(w * dpr)); c.height = Math.max(1, Math.ceil(h * dpr)); const x = c.getContext('2d'); x.scale(dpr, dpr); return { c, x, w, h }; };
  const rgba = (hex, a) => { const n = parseInt(hex.slice(1), 16); return `rgba(${n >> 16},${(n >> 8) & 255},${n & 255},${a})`; };
  const shade = (hex, f) => { const n = parseInt(hex.slice(1), 16); const q = (v) => Math.min(255, Math.floor(v * f)); return `rgb(${q(n >> 16)},${q((n >> 8) & 255)},${q(n & 255)})`; };

  function buildSprites() {
    // maple leaves
    const s = Math.max(24, 30 * d);
    const pts = [[0, -1], [.17, -.66], [.40, -.74], [.34, -.36], [.70, -.46], [.60, -.14], [.96, -.06], [.64, .22], [.72, .46], [.30, .40], [.08, .62], [.06, .98]];
    leafSpr = LEAF_COLORS.map((col) => {
      const o = mk(s, s), x = o.x, r = s / 2 - 1, c = s / 2;
      x.beginPath(); x.moveTo(c + pts[0][0] * r, c + pts[0][1] * r);
      for (let i = 1; i < pts.length; i++) x.lineTo(c + pts[i][0] * r, c + pts[i][1] * r);
      for (let i = pts.length - 1; i >= 1; i--) x.lineTo(c - pts[i][0] * r, c + pts[i][1] * r);
      x.closePath(); x.fillStyle = col; x.fill();
      x.strokeStyle = 'rgba(255,255,255,.4)'; x.lineWidth = Math.max(1, s / 22); x.lineCap = 'butt';
      x.beginPath(); x.moveTo(c, c - r * .8); x.lineTo(c, c + r * .98); x.moveTo(c, c + r * .1); x.lineTo(c + r * .6, c - r * .25); x.moveTo(c, c + r * .1); x.lineTo(c - r * .6, c - r * .25); x.stroke();
      x.strokeStyle = 'rgba(0,0,0,.33)'; x.lineWidth = Math.max(1, s / 30);
      x.beginPath(); x.moveTo(c + pts[0][0] * r, c + pts[0][1] * r);
      for (let i = 1; i < pts.length; i++) x.lineTo(c + pts[i][0] * r, c + pts[i][1] * r);
      for (let i = pts.length - 1; i >= 1; i--) x.lineTo(c - pts[i][0] * r, c + pts[i][1] * r);
      x.closePath(); x.stroke();
      return o;
    });
    // snow: two soft dots and a six-armed crystal
    flakeSpr = [10, 16, 24].map((base, k) => {
      const sz = Math.max(8, base * d), o = mk(sz, sz), x = o.x, c = sz / 2;
      if (k < 2) {
        const g = x.createRadialGradient(c, c, 0, c, c, c);
        g.addColorStop(0, 'rgba(255,255,255,1)'); g.addColorStop(.45, 'rgba(255,255,255,.8)'); g.addColorStop(1, 'rgba(255,255,255,0)');
        x.fillStyle = g; x.beginPath(); x.arc(c, c, c, 0, 6.2832); x.fill();
      } else {
        x.strokeStyle = '#fff'; x.lineCap = 'round'; x.lineWidth = Math.max(1.3, sz / 12);
        for (let i = 0; i < 3; i++) {
          const a = Math.PI * i / 3, dx = Math.cos(a) * (c - 2), dy = Math.sin(a) * (c - 2);
          x.beginPath(); x.moveTo(c - dx, c - dy); x.lineTo(c + dx, c + dy); x.stroke();
          for (let sg = -1; sg <= 1; sg += 2) {
            const mx = c + sg * dx * .62, my = c + sg * dy * .62, a1 = a + Math.PI / 4, a2 = a - Math.PI / 4, l = c * .28;
            x.beginPath(); x.moveTo(mx, my); x.lineTo(mx + Math.cos(a1) * l, my + Math.sin(a1) * l); x.moveTo(mx, my); x.lineTo(mx - Math.cos(a2) * l, my - Math.sin(a2) * l); x.stroke();
          }
        }
      }
      return o;
    });
    // shiny stars
    const tints = ['#FFF2B0', '#FFFFFF', '#BFE6FF'];
    const sz = Math.max(20, 26 * d);
    starSpr = tints.map((t) => {
      const o = mk(sz, sz), x = o.x, c = sz / 2;
      const g = x.createRadialGradient(c, c, 0, c, c, c);
      g.addColorStop(0, rgba(t, .59)); g.addColorStop(.4, rgba(t, .2)); g.addColorStop(1, rgba(t, 0));
      x.fillStyle = g; x.beginPath(); x.arc(c, c, c, 0, 6.2832); x.fill();
      const spark = (rr, fill) => { x.beginPath(); x.moveTo(c, c - rr); x.quadraticCurveTo(c, c, c + rr, c); x.quadraticCurveTo(c, c, c, c + rr); x.quadraticCurveTo(c, c, c - rr, c); x.quadraticCurveTo(c, c, c, c - rr); x.closePath(); x.fillStyle = fill; x.fill(); };
      const r = c * .92; spark(r, '#fff');
      x.save(); x.translate(c, c); x.rotate(Math.PI / 4); x.translate(-c, -c); spark(r * .55, rgba(t, .9)); x.restore();
      x.fillStyle = '#fff'; x.beginPath(); x.arc(c, c, Math.max(1.5, c * .1), 0, 6.2832); x.fill();
      return o;
    });
    // bulb glow
    haloSpr = BULB_COLORS.map((col) => {
      const hr = 17 * d, o = mk(hr * 2, hr * 2), x = o.x;
      const g = x.createRadialGradient(hr, hr, 0, hr, hr, hr);
      g.addColorStop(0, rgba(col, 1)); g.addColorStop(.35, rgba(col, .47)); g.addColorStop(1, rgba(col, 0));
      x.fillStyle = g; x.beginPath(); x.arc(hr, hr, hr, 0, 6.2832); x.fill();
      return o;
    });
  }

  function buildMoon(radius) {
    const rb = Math.max(16, radius * MOON_SS), side = rb * 2 + 12;
    const o = mk(side, side), x = o.x, c = side / 2;
    const g = x.createRadialGradient(c - rb * .35, c - rb * .4, 0, c - rb * .35, c - rb * .4, rb * 1.7);
    g.addColorStop(0, '#FFFCE6'); g.addColorStop(.35, '#FFEDB0'); g.addColorStop(.75, '#F6CA63'); g.addColorStop(1, '#D99B3B');
    x.fillStyle = g; x.beginPath(); x.arc(c, c, rb, 0, 6.2832); x.fill();
    const cr = [[-.55, .18, .17], [-.30, -.45, .11], [-.62, -.30, .08], [-.20, .52, .13], [-.78, .45, .07], [-.05, .05, .06]];
    for (const k of cr) {
      x.fillStyle = 'rgba(165,112,26,.2)'; x.beginPath(); x.arc(c + k[0] * rb, c + k[1] * rb, k[2] * rb, 0, 6.2832); x.fill();
      x.fillStyle = 'rgba(255,255,255,.19)'; x.beginPath(); x.arc(c + k[0] * rb - k[2] * rb * .18, c + k[1] * rb - k[2] * rb * .18, k[2] * rb * .78, 0, 6.2832); x.fill();
    }
    x.strokeStyle = 'rgba(255,255,255,.6)'; x.lineWidth = Math.max(2, rb * .045); x.beginPath(); x.arc(c, c, rb * .965, 0, 6.2832); x.stroke();
    x.globalCompositeOperation = 'destination-out'; x.fillStyle = '#000'; x.beginPath(); x.arc(c + rb * .62, c - rb * .10, rb * .85, 0, 6.2832); x.fill();
    moonSpr = o;
  }

  function reset(i, anywhere) {
    if (kind[i] === 0) {
      const type = rint(10) < 6 ? 0 : (rint(10) < 7 ? 1 : 2);
      size[i] = type; sub[i] = type;
      speed[i] = (type === 0 ? 55 : type === 1 ? 80 : 62) * d * (.8 + rnd() * .5);
      swayAmp[i] = (10 + rnd() * 22) * d; swaySpeed[i] = .6 + rnd() * 1.2; rotSpeed[i] = (rnd() - .5) * 60;
    } else if (kind[i] === 2) {
      size[i] = .65 + rnd() * .6; speed[i] = (58 + rnd() * 40) * d;
      swayAmp[i] = (8 + rnd() * 18) * d; swaySpeed[i] = .7 + rnd() * 1; rotSpeed[i] = (rnd() - .5) * 70; sub[i] = rint(3);
    } else {
      size[i] = .7 + rnd() * .7; speed[i] = (46 + rnd() * 34) * d;
      swayAmp[i] = (26 + rnd() * 40) * d; swaySpeed[i] = .5 + rnd() * .9; rotSpeed[i] = (rnd() - .5) * 140; sub[i] = rint(4);
    }
    px[i] = rnd() * (W || 1000);
    py[i] = anywhere ? rnd() * (H || 700) : -(30 * d) - rnd() * 60 * d;
    swayPhase[i] = rnd() * 6.283; rot[i] = rnd() * 360; flipPhase[i] = rnd() * 6.283;
  }

  function resize() {
    dpr = Math.min(2, window.devicePixelRatio || 1);
    W = cv.clientWidth; H = cv.clientHeight;
    if (!W || !H) return;
    cv.width = Math.round(W * dpr); cv.height = Math.round(H * dpr);
    d = Math.max(1, Math.min(1.6, H / 760));
    buildSprites();
    // wire: one continuous garland with a gentle sag every `seg` px
    const seg = 118 * d, sag = 8 * d, top = 1.5 * d;
    const segs = Math.max(2, Math.round(W / seg)), segW = W / segs;
    wirePath = new Path2D();
    wirePath.moveTo(-4 * d, top);
    for (let s = 0; s < segs; s++) { const x0 = s * segW, x1 = x0 + segW; wirePath.quadraticCurveTo((x0 + x1) / 2, top + sag * 2, x1 + (s === segs - 1 ? 4 * d : 0), top); }
    const gap = 38 * d, n = Math.max(6, Math.round(W / gap)), step = W / n;
    bx = []; by = []; bcol = [];
    for (let i = 0; i < n; i++) {
      const x = step * (i + .5), s = Math.min(segs - 1, Math.floor(x / segW)), t = (x - s * segW) / segW;
      bx.push(x); by.push(top + 4 * sag * t * (1 - t)); bcol.push(i % BULB_COLORS.length);
    }
    const mid = Math.floor(n / 2);
    moonAx = (bx[mid - 1] + bx[mid]) / 2;
    const ms = Math.min(segs - 1, Math.floor(moonAx / segW)), mt = (moonAx - ms * segW) / segW;
    moonAy = top + 4 * sag * mt * (1 - mt);
    moonR = 21 * d; moonL = 30 * d;
    buildMoon(moonR);
    ready = true;
    for (let i = 0; i < TOTAL; i++) { if (px[i] === 0 && py[i] === 0) reset(i, true); else if (px[i] > W) px[i] = rnd() * W; }
  }

  function drawFalling(dt) {
    for (let i = 0; i < TOTAL; i++) {
      py[i] += speed[i] * dt; rot[i] += rotSpeed[i] * dt;
      const sx = px[i] + Math.sin(clock * swaySpeed[i] + swayPhase[i]) * swayAmp[i];
      if (py[i] > H + 40 * d) { reset(i, false); continue; }
      let spr, alpha = 1, sc = 1, sx2 = 1, rotate = false;
      if (kind[i] === 0) { spr = flakeSpr[sub[i]]; alpha = sub[i] === 2 ? .92 : .84; rotate = sub[i] === 2; }
      else if (kind[i] === 2) { const tw = Math.sin(clock * 3.2 + flipPhase[i] * 2); spr = starSpr[sub[i]]; sc = size[i] * (.9 + .22 * tw); alpha = (175 + 80 * Math.abs(tw)) / 255; rotate = true; }
      else { const flip = Math.cos(clock * 1.6 + flipPhase[i]); spr = leafSpr[sub[i]]; sc = size[i]; sx2 = .25 + .75 * Math.abs(flip); alpha = .94; rotate = true; }
      ctx.save(); ctx.globalAlpha = alpha; ctx.translate(sx, py[i]);
      if (rotate) ctx.rotate(rot[i] * Math.PI / 180);
      ctx.scale(sc * sx2, sc);
      ctx.drawImage(spr.c, -spr.w / 2, -spr.h / 2, spr.w, spr.h);
      ctx.restore();
    }
  }

  function drawLights() {
    ctx.save();
    ctx.strokeStyle = '#1B1B22'; ctx.lineWidth = Math.max(1.5, 1.6 * d); ctx.lineCap = 'round';
    ctx.stroke(wirePath);
    const n = bx.length, wave = (clock * .55) % 1.6;
    for (let i = 0; i < n; i++) {
      const pos = i / (n - 1), dist = Math.abs(pos - (wave - .3)), lit = Math.max(0, 1 - dist / .22);
      const base = .62 + .12 * Math.sin(clock * 2.2 + i * .9), k = Math.min(1, base + .38 * lit);
      const x = bx[i], y = by[i], cord = 5 * d, capH = 3.6 * d, bw = 4.4 * d, bh = 6.6 * d;
      ctx.beginPath(); ctx.moveTo(x, y); ctx.lineTo(x, y + cord); ctx.stroke();
      ctx.fillStyle = '#3A3A44'; ctx.beginPath();
      if (ctx.roundRect) ctx.roundRect(x - 2.6 * d, y + cord, 5.2 * d, capH, 1 * d); else ctx.rect(x - 2.6 * d, y + cord, 5.2 * d, capH);
      ctx.fill();
      const gy = y + cord + capH + bh * .82, hs = haloSpr[bcol[i]];
      ctx.globalAlpha = 200 * k / 255; ctx.drawImage(hs.c, x - hs.w / 2, gy - hs.h / 2, hs.w, hs.h);
      ctx.globalAlpha = 1; ctx.fillStyle = shade(BULB_COLORS[bcol[i]], .55 + .55 * k);
      ctx.beginPath(); ctx.ellipse(x, gy, bw, bh, 0, 0, 6.2832); ctx.fill();
      ctx.globalAlpha = 170 * k / 255; ctx.fillStyle = '#fff';
      ctx.beginPath(); ctx.ellipse(x - bw * .25, gy - bh * .335, bw * .2, bh * .285, 0, 0, 6.2832); ctx.fill();
      ctx.globalAlpha = 1;
    }
    ctx.restore();
    drawMoon();
  }

  function drawMoon() {
    if (!moonSpr) return;
    const r = moonR, cy = moonL + r, swing = Math.sin(clock * .9) * 4.5;
    ctx.save(); ctx.translate(moonAx, moonAy); ctx.rotate(swing * Math.PI / 180);
    ctx.strokeStyle = 'rgba(255,233,168,.8)'; ctx.lineWidth = Math.max(1, 1.1 * d); ctx.lineCap = 'round';
    ctx.beginPath(); ctx.moveTo(0, 0); ctx.lineTo(-.087 * r, cy - .996 * r); ctx.moveTo(0, 0); ctx.lineTo(-.766 * r, cy - .643 * r); ctx.stroke();
    // soft glow
    const hr = r * 3.4, g = ctx.createRadialGradient(-r * .2, cy, 0, -r * .2, cy, hr);
    g.addColorStop(0, 'rgba(255,239,176,.67)'); g.addColorStop(.38, 'rgba(255,224,138,.27)'); g.addColorStop(1, 'rgba(255,224,138,0)');
    ctx.globalAlpha = Math.max(0, Math.min(1, (205 + 50 * Math.sin(clock * 1.3)) / 255));
    ctx.fillStyle = g; ctx.beginPath(); ctx.arc(-r * .2, cy, hr, 0, 6.2832); ctx.fill();
    ctx.globalAlpha = 1;
    // crescent
    ctx.save(); ctx.translate(0, cy); ctx.rotate(-18 * Math.PI / 180);
    ctx.drawImage(moonSpr.c, -moonSpr.w / MOON_SS / 2, -moonSpr.h / MOON_SS / 2, moonSpr.w / MOON_SS, moonSpr.h / MOON_SS);
    ctx.restore();
    // twinkling star in the opening
    const tw = .55 + .45 * Math.sin(clock * 3.6), sx = r * .52, sy = cy + r * .05, sr = r * .2 * (.8 + .4 * tw);
    ctx.fillStyle = `rgba(255,244,192,${(150 + 100 * tw) / 255})`;
    ctx.beginPath(); ctx.moveTo(sx, sy - sr * 1.6); ctx.quadraticCurveTo(sx, sy, sx + sr * 1.6, sy); ctx.quadraticCurveTo(sx, sy, sx, sy + sr * 1.6);
    ctx.quadraticCurveTo(sx, sy, sx - sr * 1.6, sy); ctx.quadraticCurveTo(sx, sy, sx, sy - sr * 1.6); ctx.closePath(); ctx.fill();
    ctx.restore();
  }

  function frame(ts) {
    requestAnimationFrame(frame);
    if (document.hidden || document.body.classList.contains('site-open')) { last = 0; return; }
    if (!W || !H) { resize(); if (!W) return; }
    let dt = last ? (ts - last) / 1000 : .016; last = ts; if (dt > .05) dt = .05;
    clock += dt;
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0); ctx.clearRect(0, 0, W, H);
    drawFalling(dt);
    if (ready) drawLights();
  }

  for (let i = 0; i < TOTAL; i++) { px[i] = 0; py[i] = 0; reset(i, true); px[i] = 0; py[i] = 0; }
  window.addEventListener('resize', () => { resize(); });
  requestAnimationFrame(frame);
  window.Festive = { resize };
})();
