'use strict';
// "Who's Watching?" screen (port of ProfileGate.java): profiles, 4 digit code, add / edit / delete, typed welcome
(function () {
  const T = {
    who: "Who's Watching?", manageTitle: 'Manage Profiles', manageSub: 'Enter the code to edit this profile', manage: 'Manage Profiles',
    done: 'Done', add: 'Add Profile', p1: 'Profile 1', back: 'Back', enter: 'Enter your code', wrong: 'Wrong code, try again',
    locked: (s) => `Too many attempts. Try again in ${s} s`, mismatch: 'Codes do not match, start again', newTitle: 'Add Profile', editTitle: 'Edit Profile',
    newProfile: 'New profile', nameHint: 'Name', errName: 'Please type a name', errTaken: 'This name is already used', next: 'Next', save: 'Save',
    change: 'Change code', del: 'Delete profile', delConfirm: 'Tap again to delete', codeNext: 'Next step: choose a 4 digit code',
    codeReady: 'New code ready, press Save', createCode: 'Create a 4 digit code', repeat: 'Repeat the code', codeHint: 'You will use it to enter this profile',
    forgot: 'Forgot code?', forgotConfirm: 'Delete this profile? Tap again',
  };
  const PAL = () => window.Profiles.PALETTE;
  const layers = document.getElementById('layers');
  let root, stage, auroraCv, aurora, opts, state, manage = false, finished = false, keyHandler = null;
  let failCount = 0, lockedUntil = 0;

  // ---------- aurora background ----------
  function startAurora() {
    const ctx = auroraCv.getContext('2d');
    aurora = { from: [255, 91, 91], to: [255, 91, 91], t0: 0, run: true };
    const rgb = (h) => { const n = parseInt(h.slice(1), 16); return [n >> 16, (n >> 8) & 255, n & 255]; };
    aurora.set = (hex) => { const c = rgb(hex); if (c.join() === aurora.to.join()) return; aurora.from = aurora.cur(); aurora.to = c; aurora.t0 = performance.now(); };
    aurora.cur = () => { const t = Math.max(0, Math.min(1, (performance.now() - aurora.t0) / 500)); return aurora.from.map((v, i) => Math.round(v + (aurora.to[i] - v) * t)); };
    const loop = () => {
      if (!aurora.run) return;
      requestAnimationFrame(loop);
      const dpr = Math.min(2, devicePixelRatio || 1), w = auroraCv.clientWidth, h = auroraCv.clientHeight;
      if (auroraCv.width !== Math.round(w * dpr)) { auroraCv.width = Math.round(w * dpr); auroraCv.height = Math.round(h * dpr); }
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0); ctx.fillStyle = '#050505'; ctx.fillRect(0, 0, w, h);
      const t = performance.now() / 1000, big = Math.max(w, h), col = aurora.cur();
      const glow = (x, y, r, c, a) => { const g = ctx.createRadialGradient(x, y, 0, x, y, r); g.addColorStop(0, `rgba(${c[0]},${c[1]},${c[2]},${a / 255})`); g.addColorStop(1, `rgba(${c[0]},${c[1]},${c[2]},0)`); ctx.fillStyle = g; ctx.fillRect(0, 0, w, h); };
      glow(w * (.25 + .10 * Math.sin(t * .21)), h * (.20 + .08 * Math.cos(t * .17)), big * .62, col, 0x55);
      glow(w * (.80 + .08 * Math.cos(t * .19)), h * (.85 + .06 * Math.sin(t * .23)), big * .55, col, 0x38);
      glow(w * (.55 + .12 * Math.sin(t * .13)), h * .5, big * .45, [0x3A, 0x2A, 0x7A], 0x30);
    };
    loop();
  }

  // ---------- helpers ----------
  const el = (tag, cls, html) => { const e = document.createElement(tag); if (cls) e.className = cls; if (html != null) e.innerHTML = html; return e; };
  const esc = (s) => String(s).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
  function setStage(node, st) {
    state = st; keyHandler = null;
    stage.innerHTML = ''; stage.appendChild(node);
    const f = node.querySelector('[data-focus]'); if (f) setTimeout(() => f.focus(), 30);
  }
  function tint(i) { aurora.set(PAL()[i][0]); }
  const wide = () => innerWidth >= innerHeight;
  const tileSize = (n) => { const w = innerWidth, h = innerHeight; const per = wide() ? Math.min(n, 5) : 2; const rows = Math.ceil(n / per); return Math.max(84, Math.min(150, Math.floor(Math.min((w - 80) / per - 24, (h - 250) / rows - 50)))); };

  // ---------- grid ----------
  function showGrid() {
    tint(0); const store = window.Profiles; const list = store.all();
    const placeholder = list.length === 0, slots = placeholder ? 1 : list.length, plus = store.canAdd();
    const total = slots + (plus ? 1 : 0), size = tileSize(total), per = wide() ? Math.min(total, 5) : 2;
    const col = el('div', 'col'); col.appendChild(el('div', 'brand', 'ALL TV'));
    col.appendChild(el('div', 'gtitle', manage ? T.manageTitle : T.who));
    const grid = el('div', 'pgrid'); let row = null; const active = store.getActive(); let idx = 0, focus = null;
    for (let k = 0; k < total; k++) {
      if (k % per === 0) { row = el('div', 'prow'); grid.appendChild(row); }
      const isPlus = k >= slots, prof = (!isPlus && !placeholder) ? list[idx++] : null;
      const slot = el('div', 'pslot'); slot.style.setProperty('--ps', size + 'px'); slot.style.animationDelay = (80 + k * 70) + 'ms';
      const av = el('button', 'pav'); av.setAttribute('data-av', '1');
      av.innerHTML = isPlus ? Icons.avatar(0, { plus: true }) : Icons.avatar(prof ? prof.color : 0, { edit: manage && prof });
      const lbl = el('div', 'lbl', esc(isPlus ? T.add : (prof ? prof.name : T.p1)));
      slot.appendChild(av); slot.appendChild(lbl); row.appendChild(slot);
      av.onclick = () => pick(isPlus, prof);
      av.onmouseenter = () => window.Sound && Sound.hover();
      if (!focus || (prof && active && prof.id === active.id)) focus = av;
    }
    col.appendChild(grid);
    if (!placeholder && store.count() > 0) { const mg = el('button', 'soft', manage ? T.done : T.manage); mg.onclick = () => { manage = !manage; showGrid(); }; col.appendChild(mg); }
    if (focus) focus.setAttribute('data-focus', '1');
    setStage(col, 'grid');
    keyHandler = (e) => { if (e.key === 'Escape' && opts.cancellable) { e.preventDefault(); close(); opts.onCancel && opts.onCancel(); } };
  }
  function pick(isPlus, prof) {
    const store = window.Profiles;
    if (isPlus || !prof) { if (!store.canAdd()) return; showForm(null); }
    else if (manage) showPin(prof, () => showForm(prof), true);
    else showPin(prof, () => enter(prof), false);
  }

  // ---------- code pad ----------
  function pad(onDone) {
    const wrap = el('div', 'padwrap'); wrap.style.cssText = 'display:flex;flex-direction:column;align-items:center';
    const dots = el('div', 'dots', '<i><b></b></i><i><b></b></i><i><b></b></i><i><b></b></i>');
    const msg = el('div', 'msg'); const keys = el('div', 'keys');
    const ks = wide() ? Math.max(54, Math.min(70, Math.floor((innerHeight - 380) / 4))) : 70; keys.style.setProperty('--ks', ks + 'px');
    let buf = '', locked = false;
    const upd = () => { [...dots.children].forEach((d, i) => d.classList.toggle('on', i < buf.length)); };
    const api = {
      el: wrap,
      press(d) { if (locked || buf.length >= 4) return; buf += d; msg.textContent = ''; dots.classList.remove('err', 'shake'); upd(); if (buf.length === 4) { locked = true; setTimeout(() => { if (!finished) onDone(buf, api); }, 160); } },
      back() { if (locked) return; buf = buf.slice(0, -1); upd(); },
      fail(text) { msg.textContent = text; dots.classList.add('err'); dots.classList.remove('shake'); void dots.offsetWidth; dots.classList.add('shake'); setTimeout(() => { buf = ''; locked = false; dots.classList.remove('err'); upd(); }, 520); },
      reset() { buf = ''; locked = false; msg.textContent = ''; dots.classList.remove('err', 'shake'); upd(); },
    };
    [1, 2, 3, 4, 5, 6, 7, 8, 9, -1, 0, -2].forEach((v) => {
      const b = el('button', 'key' + (v === -1 ? ' empty' : '') + (v === -2 ? ' del' : ''), v === -2 ? '&#9003;' : (v === -1 ? '' : String(v)));
      if (v >= 0) b.onclick = () => api.press(v); else if (v === -2) b.onclick = () => api.back();
      keys.appendChild(b);
    });
    wrap.appendChild(dots); wrap.appendChild(msg); wrap.appendChild(keys);
    keyHandler = (e) => {
      if (/^[0-9]$/.test(e.key)) { e.preventDefault(); api.press(+e.key); }
      else if (e.key === 'Backspace' || e.key === 'Delete') { e.preventDefault(); api.back(); }
    };
    return api;
  }
  function header(prof, title, sub) {
    const h = el('div', 'hdr'); const av = el('div', 'pav'); av.innerHTML = Icons.avatar(prof.color);
    h.appendChild(av); h.appendChild(el('div', 'nm', esc(prof.name))); h.appendChild(el('div', 'tt', esc(title)));
    if (sub) h.appendChild(el('div', 'sb', esc(sub))); return h;
  }
  function backChip(fn) { const b = el('button', 'backchip', '&#8592;&nbsp; ' + T.back); b.onclick = fn; return b; }

  function showPin(prof, ok, forManage) {
    tint(prof.color);
    const store = window.Profiles;
    const p = pad((pin) => {
      const now = performance.now();
      if (now < lockedUntil) { p.fail(T.locked(Math.ceil((lockedUntil - now) / 1000))); return; }
      if (store.checkPin(prof, pin)) { failCount = 0; ok(pin); }
      else { failCount++; if (failCount >= 5) { failCount = 0; lockedUntil = performance.now() + 30000; p.fail(T.locked(30)); } else p.fail(T.wrong); }
    });
    const page = el('div', 'col'); page.appendChild(header(prof, T.enter, forManage ? T.manageSub : null)); page.appendChild(p.el);
    if (!forManage) {
      const f = el('button', 'forgot', T.forgot); let armed = false;
      f.onclick = () => { if (!armed) { armed = true; f.textContent = T.forgotConfirm; f.classList.add('arm'); return; } store.remove(prof.id); manage = false; showGrid(); };
      page.appendChild(f);
    }
    const holder = el('div'); holder.style.cssText = 'position:absolute;inset:0;display:flex;align-items:center;justify-content:center'; holder.appendChild(page);
    holder.appendChild(backChip(() => showGrid()));
    const kh = keyHandler; setStage(holder, 'pin'); keyHandler = (e) => { if (e.key === 'Escape') { showGrid(); return; } kh(e); };
  }

  // new code (twice). cb(pin) when both match, or cancel
  function codeFlow(prof, nameForHeader, colorIdx, cb, cancel) {
    tint(colorIdx);
    const fake = { name: nameForHeader || T.newProfile, color: colorIdx };
    let first = null;
    const build = () => {
      const p = pad((pin) => {
        if (first == null) { first = pin; build(); return; }
        if (pin !== first) { first = null; p.fail(T.mismatch); setTimeout(build, 700); return; }
        cb(pin);
      });
      const page = el('div', 'col'); page.appendChild(header(fake, first == null ? T.createCode : T.repeat, T.codeHint)); page.appendChild(p.el);
      const holder = el('div'); holder.style.cssText = 'position:absolute;inset:0;display:flex;align-items:center;justify-content:center'; holder.appendChild(page);
      holder.appendChild(backChip(() => { if (first != null) { first = null; build(); } else cancel(); }));
      const kh = keyHandler; setStage(holder, 'pin'); keyHandler = (e) => { if (e.key === 'Escape') { cancel(); return; } kh(e); };
    };
    build();
  }

  // ---------- form (create / edit) ----------
  function showForm(prof, startName, startColor, newPin) {
    const store = window.Profiles, creating = !prof;
    let colorIdx = startColor != null && startColor >= 0 ? startColor : (prof ? prof.color : store.nextFreeColor());
    let pendingPin = newPin || null;
    tint(colorIdx);
    const f = el('div', 'col form'); f.appendChild(el('h2', null, creating ? T.newTitle : T.editTitle));
    const prev = el('div', 'pav'); prev.innerHTML = Icons.avatar(colorIdx); f.appendChild(prev);
    const input = el('input', 'nameinp'); input.maxLength = window.Profiles.NAME_MAX; input.placeholder = T.nameHint; input.value = startName != null ? startName : (prof ? prof.name : ''); input.setAttribute('data-focus', '1'); input.autocomplete = 'off';
    f.appendChild(input);
    const sw = el('div', 'sw'); const dots = [];
    PAL().forEach((c, i) => {
      const d = el('button', i === colorIdx ? 'on' : ''); d.style.background = c[0]; dots.push(d);
      d.onclick = () => { colorIdx = i; prev.innerHTML = Icons.avatar(i); tint(i); dots.forEach((x, k) => x.classList.toggle('on', k === i)); };
      sw.appendChild(d);
    });
    f.appendChild(sw);
    const err = el('div', 'ferr'); f.appendChild(err);
    const hint = el('div', 'fhint', creating ? T.codeNext : (pendingPin ? T.codeReady : '')); f.appendChild(hint);
    const validate = () => {
      const n = window.Profiles.clean(input.value);
      if (!n) { err.textContent = T.errName; return null; }
      if (store.nameTaken(n, prof ? prof.id : null)) { err.textContent = T.errTaken; return null; }
      err.textContent = ''; return n;
    };
    const toCode = (after) => { const n = validate(); if (!n) return; codeFlow(prof, n, colorIdx, (pin) => after(n, pin), () => showForm(prof, n, colorIdx, pendingPin)); };
    const primary = el('button', 'btn primary', creating ? T.next : T.save);
    if (creating) primary.onclick = () => toCode((n, pin) => { const p = store.add(n, pin, colorIdx); if (p) enter(p); else showGrid(); });
    else primary.onclick = () => { const n = validate(); if (!n) return; store.update(prof.id, n, colorIdx, pendingPin); manage = false; showGrid(); };
    f.appendChild(primary);
    if (!creating) {
      const ch = el('button', 'btn soft2', T.change); ch.onclick = () => toCode((n, pin) => showForm(prof, n, colorIdx, pin)); f.appendChild(ch);
      const del = el('button', 'btn soft2', T.del); let armed = false;
      del.onclick = () => { if (!armed) { armed = true; del.textContent = T.delConfirm; del.style.color = '#FF6B6B'; return; } store.remove(prof.id); manage = false; showGrid(); };
      f.appendChild(del);
    }
    const holder = el('div'); holder.style.cssText = 'position:absolute;inset:0;display:flex;align-items:center;justify-content:center;overflow:auto'; holder.appendChild(f);
    holder.appendChild(backChip(() => showGrid()));
    setStage(holder, 'form');
    input.addEventListener('keydown', (e) => { if (e.key === 'Enter') primary.click(); e.stopPropagation(); });
    keyHandler = (e) => { if (e.key === 'Escape') showGrid(); };
  }

  // ---------- welcome ----------
  function enter(prof) {
    window.Profiles.setActive(prof.id); tint(prof.color);
    const page = el('div', 'col'); const av = el('div', 'pav wlc-av'); av.innerHTML = Icons.avatar(prof.color); av.style.cssText = 'width:112px;height:112px;cursor:default';
    page.appendChild(av); const nm = el('div', 'nm', esc(prof.name)); nm.style.cssText = 'font-weight:700;font-size:20px;margin-top:12px'; page.appendChild(nm);
    const wl = el('div', 'welcome'); const l1 = el('div', 'l1'), l2 = el('div', 'l2'); wl.appendChild(l1); wl.appendChild(l2); page.appendChild(wl);
    const L1 = 'Welcome to', L2 = 'ALL TV', total = L1.length + L2.length; let t0 = performance.now() + 450, done = false, skip = false;
    const spans1 = [...L1].map((c) => { const s = el('span', null, c === ' ' ? '&nbsp;' : c); l1.appendChild(s); return s; });
    const spans2 = [...L2].map((c) => { const s = el('span', null, c === ' ' ? '&nbsp;' : c); l2.appendChild(s); return s; });
    const cur = el('span', 'cur'); const hsv = (h) => `hsl(${h % 360},100%,64%)`;
    const finish = () => { if (done) return; done = true; window.Sound && Sound.open(); close(true); opts.onEntered(prof); };
    const loop = () => {
      if (done || finished) return; requestAnimationFrame(loop);
      const now = performance.now(), el_ = Math.max(0, now - t0), typed = skip ? total : Math.min(total, Math.floor(el_ / 80));
      spans1.forEach((s, i) => { s.style.visibility = i < typed ? 'visible' : 'hidden'; s.style.color = hsv(i * 31 + (now - t0) * .09); });
      spans2.forEach((s, i) => { const gi = L1.length + i; s.style.visibility = gi < typed ? 'visible' : 'hidden'; s.style.color = hsv(gi * 31 + (now - t0) * .09); const pop = skip ? 1 : Math.min(1, (el_ - gi * 80) / 160); s.style.transform = `scale(${.7 + .3 * Math.max(0, pop)})`; s.style.opacity = Math.max(.1, pop); });
      if (typed > 0) { const last = typed <= L1.length ? spans1[typed - 1] : spans2[typed - L1.length - 1]; if (last) { last.after(cur); cur.style.background = hsv(typed * 31 + (now - t0) * .09); cur.style.visibility = (typed < total || Math.floor(now / 450) % 2 === 0) ? 'visible' : 'hidden'; } }
      if (typed >= total && el_ > total * 80 + 1100) finish();
    };
    wl.onclick = () => { skip = true; setTimeout(finish, 250); };
    setStage(page, 'welcome'); loop(); keyHandler = (e) => { if (e.key === 'Enter' || e.key === ' ' || e.key === 'Escape') { skip = true; setTimeout(finish, 200); } };
  }

  function close(fadeOut) {
    finished = true; if (aurora) aurora.run = false; document.removeEventListener('keydown', onKey, true);
    const r = root; if (!r) return;
    if (fadeOut) { r.style.transition = 'opacity .32s'; r.style.opacity = '0'; setTimeout(() => r.remove(), 340); } else r.remove();
    root = null;
  }
  const onKey = (e) => { if (keyHandler) keyHandler(e); };

  window.Login = {
    show(o) {
      if (root) return;
      opts = o; finished = false; manage = false; failCount = 0;
      root = el('div', 'layer gate'); auroraCv = el('canvas', 'aurora'); stage = el('div', 'stage');
      root.appendChild(auroraCv); root.appendChild(stage); layers.appendChild(root);
      startAurora(); document.addEventListener('keydown', onKey, true); showGrid();
    },
    isOpen: () => !!root,
  };
})();
