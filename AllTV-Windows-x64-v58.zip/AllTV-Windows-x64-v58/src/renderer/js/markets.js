'use strict';
// News button: "MARKET INTELLIGENCE" (same assets, feeds and news classifier as the Android MarketsActivity)
(function () {
  const layers = document.getElementById('layers');
  const ASSETS = [
    { section: 'STOCKS', label: 'S&P 500', symbol: '^GSPC', decimals: 0, band: 0.75 },
    { section: 'STOCKS', label: 'NASDAQ', symbol: '^IXIC', decimals: 0, band: 0.75 },
    { section: 'STOCKS', label: 'DOW', symbol: '^DJI', decimals: 0, band: 0.75 },
    { section: 'GOLD', label: 'GOLD', symbol: 'GC=F', decimals: 2, band: 0.5 },
    { section: 'FOREX', label: 'EUR/USD', symbol: 'EURUSD=X', decimals: 4, band: 0.4 },
    { section: 'FOREX', label: 'GBP/USD', symbol: 'GBPUSD=X', decimals: 4, band: 0.4 },
    { section: 'FOREX', label: 'USD/JPY', symbol: 'JPY=X', decimals: 2, band: 0.4 },
    { section: 'CRYPTO', label: 'BITCOIN', symbol: 'BTC-USD', decimals: 0, band: 1.5 },
    { section: 'CRYPTO', label: 'ETHEREUM', symbol: 'ETH-USD', decimals: 0, band: 1.5 },
    { section: 'OIL', label: 'WTI', symbol: 'CL=F', decimals: 2, band: 1.0 },
    { section: 'OIL', label: 'BRENT', symbol: 'BZ=F', decimals: 2, band: 1.0 },
  ];
  const FEEDS = [
    ['https://feeds.bbci.co.uk/news/world/rss.xml', 'BBC'], ['https://feeds.bbci.co.uk/news/business/rss.xml', 'BBC Business'],
    ['https://www.aljazeera.com/xml/rss/all.xml', 'Al Jazeera'], ['https://www.cnbc.com/id/100727362/device/rss/rss.html', 'CNBC'],
    ['https://www.coindesk.com/arc/outboundfeeds/rss/', 'CoinDesk'], ['https://www.theguardian.com/world/rss', 'The Guardian'],
  ];
  const MAX_NEWS = 12;

function decodeXml(s) {
  return s.replace(/<!\[CDATA\[([\s\S]*?)\]\]>/g, '$1')
    .replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&quot;/g, '"').replace(/&apos;/g, "'")
    .replace(/&#(\d+);/g, (m, n) => String.fromCharCode(+n)).replace(/&amp;/g, '&').trim();
}
function tagOf(block, tag) {
  const m = block.match(new RegExp('<' + tag + '[^>]*>([\\s\\S]*?)</' + tag + '>', 'i'));
  return m ? decodeXml(m[1]) : '';
}
function parseFeed(xml, source) {
  const items = [];
  const re = /<item[\s>][\s\S]*?<\/item>/gi;
  let m;
  while ((m = re.exec(xml))) {
    const b = m[0];
    const title = tagOf(b, 'title');
    if (!title) continue;
    const t = Date.parse(tagOf(b, 'pubDate'));
    items.push({ title, link: tagOf(b, 'link'), source, time: isNaN(t) ? 0 : t, impact: 0, score: 0, category: 'WORLD' });
  }
  return items;
}

function normalize(title) {
  const t = title.toLowerCase().replace(/[^a-z0-9$\- ]/g, ' ').replace(/\s+/g, ' ');
  return ' ' + t.trim() + ' ';
}
function hit(p, kw) {
  if (kw.endsWith('*')) return p.includes(' ' + kw.slice(0, -1));
  return p.includes(' ' + kw + ' ');
}
const count = (p, words) => words.reduce((n, w) => n + (hit(p, w) ? 1 : 0), 0);
const has = (p, ...words) => count(p, words) > 0;

const STRONG = ['war', 'wars', 'oil price*', 'crude', 'rate cut*', 'rate hike*', 'interest rate*', 'tariff*', 'sanction*', 'nuclear', 'missile*', 'crash*', 'recession', 'inflation', 'opec', 'ceasefire', 'cease-fire', 'invasion', 'invade*', 'default*', 'shutdown', 'bankrupt*', 'fed', 'federal reserve', 'wall street', 'airstrike*', 'hostage*', 'coup', 'embargo', 'collaps*', 'plunge*', 'trade war', 'brent', 'gold price*', 'stock market'];
const MEDIUM = ['attack*', 'death toll', 'hack*', 'stolen', 'exploit*', 'bitcoin', 'crypto*', 'binance', 'ethereum', 'blockchain', 'stocks', 'shares', 'market', 'markets', 'economy', 'economic', 'bank*', 'oil', 'gas', 'energy', 'ban', 'bans', 'protest*', 'election*', 'president', 'minister', 'talks', 'deal', 'trade', 'china', 'russia', 'ukraine', 'iran', 'israel', 'gaza', 'taiwan', 'korea', 'sudan', 'jobs', 'unemployment', 'gdp', 'dollar', 'earnings', 'ipo', 'merger', 'acquisition', 'strike*', 'conflict', 'military', 'troops', 'drone*', 'billion', 'trillion', 'investors'];
const CRYPTO_WORDS = ['bitcoin', 'crypto*', 'binance', 'ethereum', 'blockchain', 'coinbase', 'stablecoin*', 'token*'];
const CONFLICT_WORDS = ['war', 'wars', 'attack*', 'missile*', 'airstrike*', 'troops', 'military', 'hostage*', 'ceasefire', 'cease-fire', 'invasion', 'invade*', 'drone*', 'killed', 'death toll', 'conflict', 'nuclear', 'gaza', 'ukraine', 'sudan', 'darfur', 'bomb*', 'shelling'];
const ENERGY_WORDS = ['oil', 'crude', 'opec', 'gas', 'brent', 'energy', 'petrol', 'fuel'];
const ECONOMY_WORDS = ['fed', 'federal reserve', 'inflation', 'rate', 'rates', 'interest rate*', 'stocks', 'shares', 'market', 'markets', 'wall street', 'bank*', 'jobs', 'unemployment', 'gdp', 'tariff*', 'trade', 'dollar', 'recession', 'earnings', 'economy', 'economic', 'rate cut*', 'rate hike*'];
const POLITICS_WORDS = ['election*', 'president', 'minister', 'government', 'parliament', 'sanction*', 'protest*', 'vote*'];

function classify(item) {
  const t = normalize(item.title);
  const strong = count(t, STRONG), medium = count(t, MEDIUM);
  item.score = strong * 3 + medium;
  item.impact = (strong >= 1 || medium >= 6) ? 2 : (medium >= 2 ? 1 : 0);
  if (has(t, ...CRYPTO_WORDS)) item.category = 'CRYPTO';
  else if (has(t, ...CONFLICT_WORDS)) item.category = 'CONFLICT';
  else if (has(t, ...ENERGY_WORDS)) item.category = 'ENERGY';
  else if (has(t, ...ECONOMY_WORDS)) item.category = 'ECONOMY';
  else if (has(t, ...POLITICS_WORDS)) item.category = 'POLITICS';
  else item.category = 'WORLD';
}

function effectsFor(category, t) {
  const list = [];
  const E = (asset, dir) => list.push({ asset, dir });
  const calm = has(t, 'ceasefire', 'cease-fire', 'peace', 'truce', 'resolution', 'diplomatic', 'talks', 'deal', 'agreement');
  const down = has(t, 'fall*', 'drop*', 'slump*', 'plunge*', 'tumble*', 'slid*', 'declin*', 'eas*', 'slip*', 'sink*', 'sank', 'lower*', 'cut*', 'weak*');
  const up = has(t, 'rise*', 'rising', 'surge*', 'soar*', 'jump*', 'climb*', 'rall*', 'gain*', 'record', 'higher', 'spike*', 'hike*', 'boost*', 'strong*');
  if (category === 'CRYPTO') {
    const bad = has(t, 'hack*', 'stolen', 'steal*', 'fraud*', 'scam*', 'ban', 'bans', 'crash*', 'plunge*', 'fall*', 'drop*', 'lawsuit*', 'fake', 'exploit*', 'collaps*', 'bankrupt*', 'sell-off', 'selloff');
    const good = has(t, 'approv*', 'etf*', 'surge*', 'soar*', 'rall*', 'record', 'adopt*', 'rise*', 'jump*', 'gain*', 'higher');
    E('Crypto', bad && !good ? -1 : (good && !bad ? 1 : 0));
  } else if (category === 'ENERGY') {
    if (down && !up) { E('Oil', -1); E('Inflation', -1); }
    else if (up && !down) { E('Oil', 1); E('Inflation', 1); }
    else E('Oil', 0);
  } else if (category === 'CONFLICT') {
    if (calm) { E('Stocks', 1); E('Oil', -1); }
    else { E('Gold', 1); E('Oil', 1); E('Stocks', -1); }
  } else if (category === 'ECONOMY') {
    if (has(t, 'rate cut*')) { E('Stocks', 1); E('Gold', 1); E('USD', -1); }
    else if (has(t, 'rate hike*', 'raises rates', 'raise rates')) { E('Stocks', -1); E('USD', 1); E('Gold', -1); }
    else if (has(t, 'tariff*')) { E('Stocks', -1); E('USD', 1); }
    else if (has(t, 'inflation')) {
      if (down && !up) { E('Inflation', -1); E('Stocks', 1); }
      else { E('Inflation', 1); E('Stocks', -1); E('Gold', 1); }
    }
    else if (down && !up) E('Stocks', -1);
    else if (up && !down) E('Stocks', 1);
    else E('Stocks', 0);
  } else {
    if (has(t, 'sanction*')) { E('Oil', 1); E('Stocks', -1); }
    else { E('Stocks', 0); E('USD', 0); }
  }
  return list;
}

function pickNews(raw) {
  const now = Date.now();
  let result = [];
  const windows = [36 * 3600000, 96 * 3600000];
  for (const win of windows) {
    result = [];
    const seen = new Set();
    for (const item of raw) {
      if (item.time > 0 && now - item.time > win) continue;
      const n = normalize(item.title);
      const key = n.length > 40 ? n.substring(0, 40) : n;
      if (seen.has(key)) continue;
      seen.add(key);
      classify(item);
      result.push(item);
    }
    if (result.filter(i => i.impact >= 1).length >= 6) break;
  }
  result.sort((a, b) => (b.impact - a.impact) || (b.time - a.time) || (b.score - a.score));
  const good = result.filter(i => i.impact >= 1).length;
  const limit = good >= 6 ? good : 6;
  const out = [];
  for (const item of result) {
    if (out.length >= Math.min(limit, MAX_NEWS)) break;
    item.effects = effectsFor(item.category, normalize(item.title));
    out.push(item);
  }
  return out;
}


  async function loadNews() {
    const parts = await Promise.all(FEEDS.map(async ([url, src]) => { try { return parseFeed(await window.alltv.fetchText(url, { timeout: 12000 }), src); } catch (e) { return []; } }));
    return pickNews([].concat(...parts));
  }
  const GREEN = '#4ADE80', RED = '#FF5B5B', AMBER = '#FFC857', GRAY = '#8A8FB0';
  const esc = (s) => String(s).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
  const ago = (t) => { if (!t) return ''; const m = Math.max(0, Math.round((Date.now() - t) / 60000)); return m < 60 ? m + 'm ago' : (m < 2880 ? Math.round(m / 60) + 'h ago' : Math.round(m / 1440) + 'd ago'); };
  const CAT = { CRYPTO: '#B57CFF', CONFLICT: '#FF6B6B', ENERGY: '#FFA24A', ECONOMY: '#4DA6FF', POLITICS: '#3FE0D0', WORLD: '#9AA0C8' };

  let root = null, timer = null;
  function open() {
    if (root) return;
    root = document.createElement('div'); root.className = 'layer mk';
    root.innerHTML = `<button class="xbtn" id="mkX">&#10005;</button><div class="mkbody scroll"><div class="mkhead"><h1>MARKET INTELLIGENCE</h1><div id="mkUp">UPDATING...  \u00B7  LIVE FEEDS</div></div>
<div id="mkTone" class="mktone">\u25CF   MARKET TONE  \u00B7  LOADING</div><h3 style="color:#FF6B6B">GLOBAL EVENTS</h3><div id="mkNews" class="mknews"></div><div id="mkAssets"></div></div>`;
    layers.appendChild(root);
    const close = () => { clearInterval(timer); document.removeEventListener('keydown', onKey, true); root.remove(); root = null; };
    const onKey = (e) => { if (e.key === 'Escape') { e.preventDefault(); e.stopPropagation(); close(); } };
    document.addEventListener('keydown', onKey, true); root.querySelector('#mkX').onclick = close;
    buildAssets(); refresh(); timer = setInterval(refresh, 30000);
  }
  const cards = {};
  function buildAssets() {
    const host = root.querySelector('#mkAssets'); const secs = {};
    ASSETS.forEach((a) => {
      if (!secs[a.section]) { const s = document.createElement('div'); s.innerHTML = `<h3>${a.section}</h3><div class="mkgrid"></div>`; host.appendChild(s); secs[a.section] = s.querySelector('.mkgrid'); }
      const c = document.createElement('div'); c.className = 'mkcard'; c.innerHTML = `<div class="l">${esc(a.label)}</div><div class="p">--</div><div class="c">&nbsp;</div><div class="m">&nbsp;</div>`;
      secs[a.section].appendChild(c); cards[a.symbol] = c;
    });
  }
  async function refresh() {
    if (!root) return;
    const rootAtStart = root;
    const res = await Promise.all(ASSETS.map(async (a) => { try { const [price, pct] = await window.alltv.quote(a.symbol); return { a, price, pct }; } catch (e) { return { a, err: true }; } }));
    if (root !== rootAtStart) return;
    let up = 0, dn = 0;
    for (const r of res) {
      const c = cards[r.a.symbol]; if (!c || r.err) continue;
      const col = r.pct >= 0 ? GREEN : RED, mood = r.pct > r.a.band ? 'BULLISH' : (r.pct < -r.a.band ? 'BEARISH' : 'NEUTRAL');
      c.querySelector('.p').textContent = r.price.toLocaleString('en-US', { minimumFractionDigits: r.a.decimals, maximumFractionDigits: r.a.decimals });
      const ch = c.querySelector('.c'); ch.textContent = (r.pct >= 0 ? '\u25B2 ' : '\u25BC ') + (r.pct >= 0 ? '+' : '') + r.pct.toFixed(2) + '%'; ch.style.color = col;
      const m = c.querySelector('.m'); m.textContent = mood; m.style.color = mood === 'NEUTRAL' ? GRAY : col;
      if (r.a.section === 'STOCKS') { if (r.pct > r.a.band) up++; else if (r.pct < -r.a.band) dn++; }
    }
    const tone = root.querySelector('#mkTone');
    let t = 'MIXED', col = AMBER; if (up >= 2 && dn === 0) { t = 'RISK-ON'; col = GREEN; } else if (dn >= 2 && up === 0) { t = 'RISK-OFF'; col = RED; }
    tone.textContent = '\u25CF   MARKET TONE  \u00B7  ' + t; tone.style.color = col;
    root.querySelector('#mkUp').textContent = 'UPDATED ' + new Date().toTimeString().slice(0, 8) + '  \u00B7  LIVE FEEDS';
    try {
      const items = await loadNews(); if (root !== rootAtStart) return;
      const box = root.querySelector('#mkNews'); box.innerHTML = '';
      items.forEach((it) => {
        const d = document.createElement('div'); d.className = 'mkitem'; d.style.borderLeftColor = CAT[it.category] || GRAY;
        const eff = (it.effects || []).map((e) => `<b style="color:${e.dir > 0 ? GREEN : (e.dir < 0 ? RED : GRAY)}">${esc(e.asset)} ${e.dir > 0 ? '\u25B2' : (e.dir < 0 ? '\u25BC' : '\u25CF')}</b>`).join(' ');
        d.innerHTML = `<div class="t">${esc(it.title)}</div><div class="s"><span style="color:${CAT[it.category] || GRAY}">${it.category}</span> \u00B7 ${esc(it.source)} \u00B7 ${ago(it.time)} ${it.impact >= 2 ? '\u00B7 <span style="color:#FF6B6B">HIGH IMPACT</span>' : ''}</div><div class="e">${eff}</div>`;
        d.onclick = () => { if (/^https?:/.test(it.link)) window.alltv.openExternal(it.link); };
        box.appendChild(d);
      });
    } catch (e) { /* keep old list */ }
  }
  window.Markets = { open };
})();
