'use strict';
// start-up: login screen first, then the home screen
(function () {
  window.addEventListener('contextmenu', (e) => e.preventDefault());
  window.addEventListener('dragstart', (e) => e.preventDefault());
  Home.updateChip();
  Home.liveInit();
  Login.show({ cancellable: false, onEntered: () => Home.updateChip(), onCancel: () => {} });
})();
