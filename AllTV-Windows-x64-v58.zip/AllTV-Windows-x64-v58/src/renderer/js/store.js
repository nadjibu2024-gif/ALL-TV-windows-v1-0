'use strict';
// Profiles (same rules as the Android ProfileStore): up to 8, name <= 12 chars, 4 digit code kept only as salted SHA-256
(function () {
  const PALETTE = [
    ['#FF5B5B', '#C1101B'], ['#4DA6FF', '#1546D6'], ['#5BE38F', '#0E8F57'], ['#FFD84A', '#E08A00'],
    ['#B57CFF', '#5B22C9'], ['#3FE0D0', '#0A7E80'], ['#FF7AC8', '#C71E86'], ['#FF9A4D', '#D9560B'],
  ];
  const MAX = 8, NAME_MAX = 12;
  const KEY = 'alltv_profiles', KEY_ACTIVE = 'alltv_active';

  // small synchronous SHA-256 (works on file:// pages, no async needed)
  function sha256(str) {
    const utf8 = unescape(encodeURIComponent(str));
    const K = [];
    const H = [0x6a09e667, 0xbb67ae85, 0x3c6ef372, 0xa54ff53a, 0x510e527f, 0x9b05688c, 0x1f83d9ab, 0x5be0cd19];
    let p = 2, n = 0;
    const isPrime = (x) => { for (let i = 2; i * i <= x; i++) if (x % i === 0) return false; return true; };
    while (n < 64) { if (isPrime(p)) { K[n++] = (Math.cbrt(p) % 1) * 4294967296 | 0; } p++; }
    const rr = (v, a) => (v >>> a) | (v << (32 - a));
    const bytes = [];
    for (let i = 0; i < utf8.length; i++) bytes.push(utf8.charCodeAt(i));
    const bitLen = bytes.length * 8;
    bytes.push(0x80);
    while (bytes.length % 64 !== 56) bytes.push(0);
    for (let i = 7; i >= 0; i--) bytes.push(i >= 4 ? 0 : (bitLen >>> (i * 8)) & 255);
    for (let off = 0; off < bytes.length; off += 64) {
      const w = new Array(64);
      for (let i = 0; i < 16; i++) w[i] = (bytes[off + i * 4] << 24) | (bytes[off + i * 4 + 1] << 16) | (bytes[off + i * 4 + 2] << 8) | bytes[off + i * 4 + 3];
      for (let i = 16; i < 64; i++) {
        const s0 = rr(w[i - 15], 7) ^ rr(w[i - 15], 18) ^ (w[i - 15] >>> 3);
        const s1 = rr(w[i - 2], 17) ^ rr(w[i - 2], 19) ^ (w[i - 2] >>> 10);
        w[i] = (w[i - 16] + s0 + w[i - 7] + s1) | 0;
      }
      let [a, b, c, d, e, f, g, h] = H;
      for (let i = 0; i < 64; i++) {
        const S1 = rr(e, 6) ^ rr(e, 11) ^ rr(e, 25);
        const ch = (e & f) ^ (~e & g);
        const t1 = (h + S1 + ch + K[i] + w[i]) | 0;
        const S0 = rr(a, 2) ^ rr(a, 13) ^ rr(a, 22);
        const maj = (a & b) ^ (a & c) ^ (b & c);
        const t2 = (S0 + maj) | 0;
        h = g; g = f; f = e; e = (d + t1) | 0; d = c; c = b; b = a; a = (t1 + t2) | 0;
      }
      H[0] = (H[0] + a) | 0; H[1] = (H[1] + b) | 0; H[2] = (H[2] + c) | 0; H[3] = (H[3] + d) | 0;
      H[4] = (H[4] + e) | 0; H[5] = (H[5] + f) | 0; H[6] = (H[6] + g) | 0; H[7] = (H[7] + h) | 0;
    }
    return H.map((v) => (v >>> 0).toString(16).padStart(8, '0')).join('');
  }
  const hash = (id, pin) => sha256('alltv|' + id + '|' + pin);
  const uuid = () => 'p' + Date.now().toString(36) + Math.random().toString(36).slice(2, 10);

  let list = [];
  function load() {
    list = [];
    try {
      const arr = JSON.parse(localStorage.getItem(KEY) || '[]');
      for (const o of arr) {
        if (list.length >= MAX) break;
        let c = Number(o.color) | 0; if (c < 0 || c >= PALETTE.length) c = 0;
        list.push({ id: String(o.id), name: String(o.name || ''), color: c, pin: String(o.pin || '') });
      }
    } catch (e) { list = []; }
  }
  function save() { try { localStorage.setItem(KEY, JSON.stringify(list)); } catch (e) { /* ignore */ } }
  load();

  const clean = (n) => { n = String(n || '').trim().replace(/\s+/g, ' '); return n.length > NAME_MAX ? n.slice(0, NAME_MAX).trim() : n; };

  window.Profiles = {
    PALETTE, MAX, NAME_MAX, clean,
    all: () => list.slice(),
    count: () => list.length,
    canAdd: () => list.length < MAX,
    byId: (id) => list.find((p) => p.id === id) || null,
    getActive: () => window.Profiles.byId(localStorage.getItem(KEY_ACTIVE)),
    setActive: (id) => { try { localStorage.setItem(KEY_ACTIVE, id); } catch (e) { /* ignore */ } },
    nextFreeColor() {
      for (let c = 0; c < PALETTE.length; c++) if (!list.some((p) => p.color === c)) return c;
      return list.length % PALETTE.length;
    },
    nameTaken(name, exceptId) {
      const n = clean(name).toLowerCase();
      return list.some((p) => p.name.toLowerCase() === n && p.id !== exceptId);
    },
    add(name, pin, color) {
      if (list.length >= MAX) return null;
      const id = uuid();
      const p = { id, name: clean(name), color, pin: hash(id, pin) };
      list.push(p); save(); return p;
    },
    update(id, name, color, newPin) {
      const p = window.Profiles.byId(id); if (!p) return;
      p.name = clean(name); p.color = color;
      if (newPin != null) p.pin = hash(p.id, newPin);
      save();
    },
    remove(id) {
      const i = list.findIndex((p) => p.id === id); if (i < 0) return;
      list.splice(i, 1); save();
      if (localStorage.getItem(KEY_ACTIVE) === id) { try { localStorage.removeItem(KEY_ACTIVE); } catch (e) { /* ignore */ } }
    },
    checkPin: (p, pin) => !!p && pin != null && hash(p.id, pin) === p.pin,
    _sha256: sha256,
  };

  // simple preferences (last site ...)
  window.Prefs = {
    get: (k, d) => { try { const v = localStorage.getItem('alltv_' + k); return v == null ? d : v; } catch (e) { return d; } },
    set: (k, v) => { try { localStorage.setItem('alltv_' + k, String(v)); } catch (e) { /* ignore */ } },
  };
})();
