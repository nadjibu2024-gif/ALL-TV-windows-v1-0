'use strict';
// TV World and Free TV: M3U lists with search / categories / countries and a built-in player (hls.js)
(function () {
  const layers = document.getElementById('layers');
  const CATS = {"News": "أخبار", "Sports": "رياضة", "Entertainment": "ترفيه", "Movies": "أفلام", "Music": "موسيقى", "Kids": "أطفال", "Religious": "ديني", "General": "عامة", "Documentary": "وثائقي", "Series": "مسلسلات", "Culture": "ثقافة", "Education": "تعليم", "Comedy": "كوميديا", "Lifestyle": "نمط حياة", "Animation": "رسوم متحركة", "Business": "أعمال", "Classic": "كلاسيكي", "Cooking": "طبخ", "Family": "عائلي", "Outdoor": "خارجية", "Relax": "استرخاء", "Travel": "سفر", "Weather": "طقس", "Auto": "سيارات", "Legislative": "برلماني", "Science": "علوم", "Shop": "تسوق", "Public": "حكومية", "Undefined": "غير مصنفة"};
  const esc = (s) => String(s).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
  const el = (tag, cls, html) => { const e = document.createElement(tag); if (cls) e.className = cls; if (html != null) e.innerHTML = html; return e; };
function attr(line, key) {
  const needle = key + '="';
  const i = line.indexOf(needle);
  if (i < 0) return '';
  const s = i + needle.length;
  const e = line.indexOf('"', s);
  return e < 0 ? '' : line.substring(s, e).trim();
}
function stripMarks(name) {
  return name.replace(/[\u24B6-\u24E9]/g, '').trim();
}
function isWebPage(url) {
  let h = '';
  try { h = new URL(url).hostname.toLowerCase(); } catch (e) { return false; }
  return h.endsWith('youtube.com') || h === 'youtu.be' || h.endsWith('twitch.tv') ||
    h.endsWith('dailymotion.com') || h.endsWith('facebook.com') || h.endsWith('vimeo.com');
}

// returns [{n,u,l,c,g,cats,r,a}]  n name, u url, l logo, c country, g group, r referrer, a user agent
function parse(text) {
  const out = [];
  let cur = null;
  for (let raw of text.split(/\r?\n/)) {
    const line = raw.trim();
    if (!line) continue;
    if (line.startsWith('#EXTINF')) {
      cur = { n: '', u: '', l: attr(line, 'tvg-logo'), c: '', g: attr(line, 'group-title'), cats: [], r: '', a: '' };
      let id = attr(line, 'tvg-id');
      const at = id.indexOf('@');
      if (at >= 0) id = id.substring(0, at);
      const dot = id.lastIndexOf('.');
      if (dot >= 0 && id.length - dot - 1 === 2) {
        let cc = id.substring(dot + 1).toLowerCase();
        if (cc === 'uk') cc = 'gb';
        cur.c = cc;
      }
      const tc = attr(line, 'tvg-country').toLowerCase();
      if (tc.length === 2) cur.c = tc === 'uk' ? 'gb' : tc;
      const lq = line.lastIndexOf('"');
      const comma = line.indexOf(',', lq < 0 ? 0 : lq);
      let nm = comma >= 0 ? line.substring(comma + 1).trim() : '';
      if (!nm) nm = attr(line, 'tvg-name');
      nm = stripMarks(nm);
      cur.n = nm || '?';
      if (cur.g) cur.cats = cur.g.split(';').map(s => s.trim());
    } else if (line.startsWith('#EXTVLCOPT:')) {
      if (cur) {
        const body = line.substring(11);
        const eq = body.indexOf('=');
        if (eq > 0) {
          const k = body.substring(0, eq).trim().toLowerCase();
          const v = body.substring(eq + 1).trim();
          if (k === 'http-referrer' || k === 'http-referer') cur.r = v;
          else if (k === 'http-user-agent') cur.a = v;
        }
      }
    } else if (line[0] === '#') {
      continue;
    } else {
      if (cur && /^https?:\/\//i.test(line) && !isWebPage(line)) {
        cur.u = line;
        if (!cur.cats.some(c => c.toUpperCase() === 'XXX')) out.push(cur);
      }
      cur = null;
    }
  }
  return out;
}


  let regionNames = null; try { regionNames = new Intl.DisplayNames(['ar'], { type: 'region' }); } catch (e) { /* keep codes */ }
  const countryName = (c) => { if (!c) return 'غير محدد'; try { const n = regionNames && regionNames.of(c.toUpperCase()); if (n && n.toLowerCase() !== c) return n; } catch (e) { /* ignore */ } return c.toUpperCase(); };
  const lists = {};

  function open(mode, onClose) {
    const free = mode === 'free';
    const portrait = innerHeight > innerWidth;
    const bg = free ? (portrait ? 'assets/bg/bg_freetv_p.jpg' : 'assets/bg/bg_freetv.jpg') : (portrait ? 'assets/bg/bg_tvworld_p.jpg' : 'assets/bg/bg_tvworld.jpg');
    const root = el('div', 'layer tvl'); root.style.backgroundImage = `linear-gradient(rgba(0,0,0,.55),rgba(0,0,0,.78)),url(${bg})`;
    root.innerHTML = `<div class="tvhead"><button class="chipb" id="tvBack">&#8249;  رجوع</button><div class="tvt">${free ? 'Free TV' : 'TV World'}</div><button class="chipb" id="tvRef">تحديث</button></div>
<div class="tvbar"><div id="tvTabs" ${free ? 'hidden' : ''}><button class="chipb" data-s="ara">قنوات عربية</button><button class="chipb" data-s="world">🌍 باقي الدول العالم</button></div>
<input id="tvQ" class="tvq" placeholder="ابحث عن قناة…"><button class="chipb" id="tvCountry">🌐 الدولة</button><span id="tvCount"></span></div>
<div id="tvCats" class="tvcats scroll"></div><div id="tvStatus" class="tvstatus"></div><div id="tvGrid" class="tvgrid scroll"></div>
<div id="tvPlayer" class="tvplayer" hidden><video id="tvVideo" autoplay playsinline></video><div id="tvMsg"></div>
<div id="tvCtl" class="tvctl"><button class="chipb" id="pBack">&#8249;  رجوع</button><div id="pName"></div><button class="chipb" id="pPrev">&#9664;  السابق</button><button class="chipb" id="pNext">التالي  &#9654;</button><button class="chipb" id="pSize">الحجم</button></div></div>`;
    layers.appendChild(root);
    const $ = (id) => root.querySelector('#' + id);
    let section = free ? 'free' : (Prefs.get('tv_section', 'ara') === 'world' ? 'world' : 'ara');
    let cat = '', country = '', query = '', shown = [], pos = -1, hls = null, sizeMode = 0, closed = false, ctlTimer = null;

    function close() { closed = true; stop(); window.alltv.streamHeaders(null); document.removeEventListener('keydown', onKey, true); root.remove(); if (onClose) onClose(); }
    function stop() { if (hls) { try { hls.destroy(); } catch (e) { /* ignore */ } hls = null; } const v = $('tvVideo'); try { v.pause(); v.removeAttribute('src'); v.load(); } catch (e) { /* ignore */ } }

    async function load(force) {
      const st = $('tvStatus'); st.innerHTML = '<div class="spin"></div> جارٍ تحميل القنوات…'; st.hidden = false;
      try {
        if (!lists[section] || force) lists[section] = parse(await window.alltv.playlist(section, !!force));
        if (closed) return; st.hidden = true; Prefs.set('tv_section', section); rebuildCats(); apply();
      } catch (e) { if (closed) return; st.innerHTML = 'تعذّر تحميل القنوات، تحقق من الإنترنت. <button class="chipb" id="tvRetry">إعادة المحاولة</button>'; st.querySelector('#tvRetry').onclick = () => load(true); $('tvGrid').innerHTML = ''; }
    }
    function tabs() { root.querySelectorAll('#tvTabs button').forEach((b) => b.classList.toggle('on', b.dataset.s === section)); }
    function rebuildCats() {
      const box = $('tvCats'); box.innerHTML = ''; const seen = {};
      for (const c of lists[section] || []) for (const k of c.cats) seen[k] = (seen[k] || 0) + 1;
      const keys = Object.keys(seen).sort((a, b) => seen[b] - seen[a]).slice(0, 30);
      const add = (key, label) => { const b = el('button', 'chipb' + (cat === key ? ' on' : ''), esc(label)); b.onclick = () => { cat = key; rebuildCats(); apply(); }; box.appendChild(b); };
      add('', 'الكل'); keys.forEach((k) => add(k, CATS[k] || k));
    }
    function apply() {
      const q = query.trim().toLowerCase(); shown = [];
      for (const c of lists[section] || []) { if (cat && !c.cats.includes(cat)) continue; if (country && c.c !== country) continue; if (q && !c.n.toLowerCase().includes(q)) continue; shown.push(c); }
      $('tvCount').textContent = shown.length + ' قناة';
      const g = $('tvGrid'); g.innerHTML = '';
      if (!shown.length) { const st = $('tvStatus'); st.textContent = 'لا توجد قنوات مطابقة'; st.hidden = false; return; }
      $('tvStatus').hidden = true;
      const frag = document.createDocumentFragment(); const lim = Math.min(shown.length, 600);
      for (let i = 0; i < lim; i++) {
        const c = shown[i], d = el('button', 'tvcard'); d.innerHTML = `<div class="lg">${c.l ? `<img loading="lazy" src="${esc(c.l)}" onerror="this.remove()">` : ''}<span>${esc(c.n.slice(0, 2))}</span></div><div class="nm">${esc(c.n)}</div>`;
        d.onclick = () => play(i); frag.appendChild(d);
      }
      g.appendChild(frag);
      if (shown.length > lim) { const m = el('button', 'chipb', 'عرض المزيد'); m.style.gridColumn = '1/-1'; m.onclick = () => { for (let i = lim; i < Math.min(shown.length, lim + 600); i++) { const c = shown[i], d = el('button', 'tvcard'); d.innerHTML = `<div class="lg">${c.l ? `<img loading="lazy" src="${esc(c.l)}" onerror="this.remove()">` : ''}<span>${esc(c.n.slice(0, 2))}</span></div><div class="nm">${esc(c.n)}</div>`; const k = i; d.onclick = () => play(k); g.insertBefore(d, m); } m.remove(); }; g.appendChild(m); }
    }

    function showCtl() { const c = $('tvCtl'); c.classList.add('on'); clearTimeout(ctlTimer); ctlTimer = setTimeout(() => c.classList.remove('on'), 3500); }
    function msg(t) { const m = $('tvMsg'); m.textContent = t || ''; m.style.display = t ? 'block' : 'none'; }
    function play(i) {
      if (i < 0 || i >= shown.length) return; pos = i; const c = shown[i];
      $('tvPlayer').hidden = false; $('pName').textContent = c.n; msg('جارٍ التحميل…'); showCtl(); stop();
      window.alltv.streamHeaders({ referrer: c.r || '', userAgent: c.a || '' });
      const v = $('tvVideo'); v.muted = false; applySize();
      const hlsLike = /\.m3u8?(\?|$)/i.test(c.u) || !/\.(mp4|mkv|webm|ts)(\?|$)/i.test(c.u);
      const fail = () => { if (pos !== i || closed) return; msg('تعذّر تشغيل هذه القناة. جرّب القناة التالية.'); };
      v.onplaying = () => { if (pos === i) { msg(''); setTimeout(() => { try { const ab = v.audioTracks; if (v.webkitAudioDecodedByteCount === 0 && v.currentTime > 4) msg('هذه القناة لا تبث صوتاً (المشكلة من المصدر نفسه).'); } catch (e) { /* ignore */ } }, 5000); } };
      v.onwaiting = () => { if (pos === i) msg('جارٍ التحميل…'); };
      v.onerror = fail;
      if (hlsLike && window.Hls && Hls.isSupported()) {
        hls = new Hls({ enableWorker: true, lowLatencyMode: false, maxBufferLength: 20, manifestLoadingMaxRetry: 2, levelLoadingMaxRetry: 2, fragLoadingMaxRetry: 3 });
        hls.on(Hls.Events.ERROR, (e, d) => { if (!d.fatal) return; if (d.type === Hls.ErrorTypes.NETWORK_ERROR && (hls.__r = (hls.__r || 0) + 1) < 3) hls.startLoad(); else if (d.type === Hls.ErrorTypes.MEDIA_ERROR && (hls.__m = (hls.__m || 0) + 1) < 3) hls.recoverMediaError(); else fail(); });
        hls.loadSource(c.u); hls.attachMedia(v); hls.on(Hls.Events.MANIFEST_PARSED, () => { const p = v.play(); if (p && p.catch) p.catch(() => {}); });
      } else { v.src = c.u; const p = v.play(); if (p && p.catch) p.catch(fail); }
    }
    function applySize() { const v = $('tvVideo'); v.style.objectFit = ['contain', 'cover', 'fill'][sizeMode]; }
    function closePlayer() { pos = -1; stop(); window.alltv.streamHeaders(null); $('tvPlayer').hidden = true; }
    function step(d) { if (!shown.length) return; play((pos + d + shown.length) % shown.length); }

    function pickCountry() {
      const counts = {}; for (const c of lists[section] || []) counts[c.c] = (counts[c.c] || 0) + 1;
      const keys = Object.keys(counts).sort((a, b) => countryName(a).localeCompare(countryName(b), 'ar'));
      const m = el('div', 'layer modal'); const card = el('div', 'card scroll'); card.style.maxHeight = '80vh';
      card.innerHTML = '<h2>🌐 الدولة</h2>'; const row = el('div', 'row');
      const add = (code, label) => { const b = el('button', 'btn soft2', esc(label)); b.onclick = () => { country = code; $('tvCountry').textContent = code ? '🌐 ' + countryName(code) : '🌐 الدولة'; m.remove(); apply(); }; row.appendChild(b); };
      add('', 'كل الدول'); keys.forEach((k) => add(k, countryName(k) + '  (' + counts[k] + ')'));
      card.appendChild(row); m.appendChild(card); layers.appendChild(m); m.onmousedown = (e) => { if (e.target === m) m.remove(); };
    }

    $('tvBack').onclick = close; $('tvRef').onclick = () => load(true); $('tvCountry').onclick = pickCountry;
    $('tvQ').oninput = (e) => { query = e.target.value; apply(); };
    root.querySelectorAll('#tvTabs button').forEach((b) => { b.onclick = () => { section = b.dataset.s; cat = ''; country = ''; $('tvCountry').textContent = '🌐 الدولة'; tabs(); load(false); }; });
    $('pBack').onclick = closePlayer; $('pPrev').onclick = () => step(-1); $('pNext').onclick = () => step(1);
    $('pSize').onclick = () => { sizeMode = (sizeMode + 1) % 3; applySize(); msg(['ملاءمة الشاشة', 'ملء الشاشة', 'تمديد'][sizeMode]); setTimeout(() => msg(''), 900); };
    $('tvPlayer').onmousemove = showCtl; $('tvPlayer').ondblclick = () => window.alltv.toggleFullscreen();
    const onKey = (e) => {
      if (!$('tvPlayer').hidden) {
        if (e.key === 'Escape' || e.key === 'Backspace') { e.preventDefault(); e.stopPropagation(); closePlayer(); }
        else if (e.key === 'ArrowRight' || e.key === 'PageDown') { e.preventDefault(); step(1); } else if (e.key === 'ArrowLeft' || e.key === 'PageUp') { e.preventDefault(); step(-1); }
        else if (e.key === 'f' || e.key === 'F') window.alltv.toggleFullscreen(); else if (e.key === ' ') { const v = $('tvVideo'); v.paused ? v.play() : v.pause(); e.preventDefault(); }
        showCtl(); return;
      }
      if (e.key === 'Escape' && document.activeElement !== $('tvQ')) { e.preventDefault(); e.stopPropagation(); close(); }
    };
    document.addEventListener('keydown', onKey, true);
    tabs(); load(false);
  }
  window.TvLists = { open };
})();
