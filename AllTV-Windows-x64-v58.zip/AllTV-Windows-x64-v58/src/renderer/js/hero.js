'use strict';
// Background scene behind the icon strip (port of HeroScene.java): picture of each site (landscape / portrait),
// live picture of the real home page, or the animated motif; colour wash, scrim, cross-fade + slide.
(function () {
  const S = window.ALLTV_SITES;
  const cv = document.getElementById('hero');
  const ctx = cv.getContext('2d');
  const N = S.length;
  let W = 0, H = 0, dpr = 1, portrait = false;
  let cur = 0, prev = -1, fade = 1, dir = 1, fadeT0 = 0, drift = 0, phase = 0;

  const hex2rgb = (h) => { const n = parseInt(h.slice(1), 16); return [n >> 16, (n >> 8) & 255, n & 255]; };
  const rgba = (c, a) => `rgba(${c[0]},${c[1]},${c[2]},${Math.max(0, Math.min(1, a))})`;
  function rotHue(rgb, deg) {
    let [r, g, b] = rgb.map((v) => v / 255);
    const mx = Math.max(r, g, b), mn = Math.min(r, g, b), df = mx - mn;
    let h = 0;
    if (df) { if (mx === r) h = ((g - b) / df) % 6; else if (mx === g) h = (b - r) / df + 2; else h = (r - g) / df + 4; h *= 60; if (h < 0) h += 360; }
    const s = mx ? df / mx : 0, v = mx;
    h = (h + deg) % 360;
    const f = (n) => { const k = (n + h / 60) % 6; return Math.round((v - v * s * Math.max(0, Math.min(k, 4 - k, 1))) * 255); };
    return [f(5), f(3), f(1)];
  }
  const C1 = S.map((s) => hex2rgb(s.color));
  const C2 = C1.map((c) => rotHue(c, 50));

  // pictures
  const img = { l: new Array(N), p: new Array(N), tile: new Array(N), liveL: new Array(N), liveP: new Array(N) };
  const liveA = new Array(N).fill(0), liveFade = new Array(N).fill(false);
  function load(src, cb) { const im = new Image(); im.decoding = 'async'; im.onload = () => cb(im); im.onerror = () => {}; im.src = src; }
  function ensure(i) {
    if (i < 0 || i >= N) return;
    const s = S[i];
    if (s.bg && !img.l[i]) { img.l[i] = 'x'; load(s.bg, (im) => { img.l[i] = im; }); }
    if (s.bgP && !img.p[i]) { img.p[i] = 'x'; load(s.bgP, (im) => { img.p[i] = im; }); }
    if (!img.tile[i]) { img.tile[i] = 'x'; load(s.tile, (im) => { img.tile[i] = im; }); }
  }
  const ok = (v) => v && v !== 'x';

  function setLive(i, file, isPortrait) {
    const url = 'file:///' + String(file).replace(/\\/g, '/').replace(/^\/+/, '') + '?t=' + Date.now();
    load(url, (im) => {
      (isPortrait ? img.liveP : img.liveL)[i] = im;
      if (liveA[i] < 1 && !liveFade[i]) {
        liveFade[i] = true; const t0 = performance.now(), a0 = liveA[i];
        const step = (t) => { const f = Math.min(1, (t - t0) / 800); liveA[i] = a0 + (1 - a0) * f; if (f < 1) requestAnimationFrame(step); };
        requestAnimationFrame(step);
      }
    });
  }

  // geometry that depends on the screen
  let cell = 1, beamW = 1, glowR = 1;
  function resize() {
    dpr = Math.min(2, window.devicePixelRatio || 1);
    W = cv.clientWidth; H = cv.clientHeight;
    cv.width = Math.round(W * dpr); cv.height = Math.round(H * dpr);
    portrait = H > W;
    glowR = Math.max(W, H) * (portrait ? .62 : .55);
    beamW = Math.max(W, H) * .22;
    cell = Math.min(W, H) * (portrait ? .20 : .17);
  }

  // particles
  const PN = 34; const ppx = [], ppy = [], pps = [];
  let sd = 7; const rn = () => { sd = (sd * 1664525 + 1013904223) >>> 0; return sd / 4294967296; };
  for (let k = 0; k < PN; k++) { ppx.push(rn()); ppy.push(rn()); pps.push(.4 + rn() * .9); }

  function crescentPath(cx, cy, cr) { // returns drawer
    return (fill) => {
      ctx.save();
      ctx.beginPath(); ctx.rect(-5000, -5000, 10000, 10000); ctx.arc(cx + cr * .42, cy - cr * .12, cr * .82, 0, 6.2832, true);
      ctx.clip('evenodd');
      ctx.fillStyle = fill; ctx.beginPath(); ctx.arc(cx, cy, cr, 0, 6.2832); ctx.fill();
      ctx.restore();
    };
  }

  function beams(i, a, count) {
    const g = ctx.createLinearGradient(0, 0, beamW, 0);
    g.addColorStop(0, rgba(C1[i], 0)); g.addColorStop(.5, rgba(C1[i], 90 / 255)); g.addColorStop(1, rgba(C2[i], 0));
    ctx.save(); ctx.globalAlpha = a; ctx.translate(W / 2, H / 2); ctx.rotate(22 * Math.PI / 180); ctx.translate(-W / 2, -H / 2);
    const span = W + H + beamW * 2;
    for (let k = 0; k < count; k++) {
      const f = (phase + k / count) % 1, left = -beamW + span * f - H * .5;
      ctx.save(); ctx.translate(left, 0); ctx.fillStyle = g; ctx.fillRect(0, -H, beamW, H * 2); ctx.restore();
    }
    ctx.restore();
  }

  function particles(i, a) {
    ctx.fillStyle = rgba(C2[i], 1);
    for (let k = 0; k < PN; k++) {
      let y = (ppy[k] - phase * pps[k] * .6) % 1; if (y < 0) y += 1;
      const x = ppx[k] * W + drift * pps[k] * W * .015;
      const tw = .5 + .5 * Math.sin(phase * 6.2832 * 2 + k);
      ctx.globalAlpha = a * (.15 + .45 * tw);
      ctx.beginPath(); ctx.arc(x, y * H * .75, (1.2 + pps[k] * 1.6) * Math.min(W, H) / 540, 0, 6.2832); ctx.fill();
    }
    ctx.globalAlpha = 1;
  }

  function wave(i, a, k, baseY, amp, segs, ph, mul, col) {
    ctx.beginPath();
    for (let q = 0; q <= segs; q++) { const x = W * q / segs, y = baseY + amp * Math.sin(q * mul + ph); q ? ctx.lineTo(x, y) : ctx.moveTo(x, y); }
    ctx.strokeStyle = col; ctx.stroke();
  }

  function motif(i, a) {
    const st = S[i].style, base = Math.min(W, H), c1 = C1[i], c2 = C2[i];
    ctx.lineJoin = 'round';
    if (st === 1) {
      beams(i, a, 3); ctx.lineWidth = Math.max(2, base * .004);
      for (let k = 0; k < 3; k++) {
        const r = base * (.22 + .16 * k), cx = W * (portrait ? .5 : .34), cy = H * (portrait ? .30 : .40);
        ctx.save(); ctx.translate(cx, cy); ctx.rotate(phase * 360 * (k % 2 ? -1 : 1) * .5 * Math.PI / 180);
        ctx.beginPath(); for (let c = 0; c < 3; c++) { const an = c * 2.0944; c ? ctx.lineTo(Math.cos(an) * r, Math.sin(an) * r) : ctx.moveTo(Math.cos(an) * r, Math.sin(an) * r); } ctx.closePath();
        ctx.strokeStyle = rgba(k === 1 ? c2 : c1, a * (.55 - .12 * k)); ctx.stroke(); ctx.restore();
      }
    } else if (st === 2) {
      const g = ctx.createLinearGradient(0, 0, 0, H * .7);
      g.addColorStop(0, 'rgba(255,255,255,.35)'); g.addColorStop(.5, rgba(c1, 40 / 255)); g.addColorStop(1, rgba(c1, 0));
      ctx.globalAlpha = a; ctx.fillStyle = g; ctx.beginPath();
      ctx.moveTo(W * .47, 0); ctx.lineTo(W * .53, 0); ctx.lineTo(W * (portrait ? .98 : .8), H * .7); ctx.lineTo(W * (portrait ? .02 : .2), H * .7); ctx.closePath(); ctx.fill(); ctx.globalAlpha = 1;
      const pw = base * .05, ph = pw * 1.3, step = pw * 1.9, off = (phase * step * 6) % step, y1 = H * .045, y2 = H * .56;
      ctx.fillStyle = rgba(c2, a * .4);
      for (let x = -step + off; x < W + step; x += step) { for (const y of [y1, y2]) { ctx.beginPath(); ctx.roundRect ? ctx.roundRect(x, y, pw, ph, pw * .25) : ctx.rect(x, y, pw, ph); ctx.fill(); } }
      ctx.lineWidth = Math.max(2, base * .003); ctx.strokeStyle = rgba(c1, a * .45);
      ctx.beginPath(); ctx.moveTo(0, y1 + ph * 1.5); ctx.lineTo(W, y1 + ph * 1.5); ctx.moveTo(0, y2 - ph * .5); ctx.lineTo(W, y2 - ph * .5); ctx.stroke();
    } else if (st === 3) {
      beams(i, a, 2); const cx = W * (portrait ? .5 : .34), cy = H * (portrait ? .30 : .40), mr = base * .75;
      ctx.lineWidth = Math.max(2, base * .005);
      for (let k = 0; k < 4; k++) { const f = (phase * 2 + k / 4) % 1; ctx.strokeStyle = rgba(k % 2 ? c2 : c1, a * .7 * (1 - f)); ctx.beginPath(); ctx.arc(cx, cy, mr * f, 0, 6.2832); ctx.stroke(); }
    } else if (st === 4) {
      ctx.lineWidth = Math.max(1.5, base * .0028); ctx.strokeStyle = `rgba(255,214,102,${a * .2})`;
      const r = cell * .42, sh = phase * cell;
      for (let gy = -cell + sh; gy < H * .66; gy += cell) for (let gx = -cell + sh; gx < W + cell; gx += cell) {
        ctx.save(); ctx.translate(gx, gy); ctx.beginPath();
        for (let q = 0; q < 2; q++) { for (let c = 0; c < 4; c++) { const an = (q * 45 + c * 90) * Math.PI / 180; c ? ctx.lineTo(Math.cos(an) * r, Math.sin(an) * r) : ctx.moveTo(Math.cos(an) * r, Math.sin(an) * r); } ctx.closePath(); }
        ctx.moveTo(r * .45, 0); ctx.arc(0, 0, r * .45, 0, 6.2832); ctx.stroke(); ctx.restore();
      }
      crescent(a, 'rgb(255,214,102)', drift * base * .01, .07);
    } else if (st === 5) {
      beams(i, a, 2); const step = cell * .9, half = step * .16; let gi = 0;
      for (let gy = step * .5; gy < H * .66; gy += step) {
        for (let gx = step * .5 + (gi % 2) * step * .5; gx < W + step; gx += step) {
          const pu = .5 + .5 * Math.sin(phase * 12.566 + gx * .012 + gy * .017);
          ctx.fillStyle = rgba(c1, a * (.05 + .22 * pu)); ctx.save(); ctx.translate(gx, gy); ctx.rotate(Math.PI / 4); ctx.fillRect(-half, -half, half * 2, half * 2); ctx.restore();
        }
        gi++;
      }
    } else if (st === 6) {
      ctx.lineWidth = Math.max(2, base * .006);
      for (let k = 0; k < 4; k++) wave(i, a, k, H * (.16 + .11 * k), H * (.035 + .01 * k), 36, phase * 6.2832 * (k % 2 ? -1 : 1) + k, .35, rgba(k % 2 ? c2 : c1, a * (.6 - .1 * k)));
    } else if (st === 7) {
      const pr = portrait ? base * .2 : H * .19, pcx = W * (portrait ? .5 : .36), pcy = H * (portrait ? .30 : .38) + drift * base * .008;
      ctx.fillStyle = rgba(c1, a * .3); ctx.beginPath(); ctx.arc(pcx, pcy, pr * 1.25, 0, 6.2832); ctx.fill();
      ctx.fillStyle = rgba(c1, a * .55); ctx.beginPath(); ctx.arc(pcx, pcy, pr, 0, 6.2832); ctx.fill();
      ctx.fillStyle = `rgba(255,255,255,${a * .18})`; ctx.beginPath(); ctx.arc(pcx - pr * .3, pcy - pr * .3, pr * .55, 0, 6.2832); ctx.fill();
      ctx.lineWidth = Math.max(2, base * .007); ctx.strokeStyle = `rgba(255,255,255,${a * .6})`;
      ctx.beginPath(); ctx.ellipse(pcx, pcy, pr * 2, pr * .45, -18 * Math.PI / 180, 0, 6.2832); ctx.stroke();
      const an = phase * 6.2832; ctx.fillStyle = rgba(c2, a); ctx.beginPath(); ctx.arc(pcx + Math.cos(an) * pr * 2, pcy + Math.sin(an) * pr * .9, pr * .12, 0, 6.2832); ctx.fill();
    } else if (st === 8) {
      ctx.lineWidth = Math.max(2, base * .005);
      for (let k = 0; k < PN; k += 2) {
        let y = (ppy[k] - phase * pps[k] * .8) % 1; if (y < 0) y += 1;
        const x = ppx[k] * W + Math.sin(phase * 6.2832 + k) * W * .02;
        ctx.strokeStyle = rgba(k % 4 ? c2 : c1, a * .55); ctx.beginPath(); ctx.arc(x, y * H * .75, base * (.018 + .035 * pps[k]), 0, 6.2832); ctx.stroke();
      }
      beams(i, a, 2);
    } else if (st === 9) {
      ctx.lineWidth = Math.max(2, base * .006);
      for (let k = 0; k < 5; k++) wave(i, a, k, H * (.10 + .12 * k), H * .03, 40, -phase * 12.566 + k * .8, .28, k % 2 ? `rgba(255,255,255,${a * .28})` : rgba(c1, a * .55));
      const acr = portrait ? base * .13 : H * .15, acx = portrait ? W * .8 : W * .82, acy = portrait ? H * .2 : H * .27;
      ctx.save(); ctx.translate(0, drift * base * .01);
      const cres = crescentPath(acx, acy, acr);
      for (let k = 3; k >= 1; k--) { ctx.save(); ctx.translate(acx, acy); ctx.scale(1 + .08 * k, 1 + .08 * k); ctx.translate(-acx, -acy); cres(`rgba(210,16,52,${a * .08 * (4 - k)})`); ctx.restore(); }
      cres(`rgba(210,16,52,${a * .95})`);
      const scx = acx + acr * .4, scy = acy - acr * .1, r1 = acr * .3, r2 = r1 * .42;
      ctx.fillStyle = `rgba(210,16,52,${a * .95})`; ctx.beginPath();
      for (let c = 0; c < 10; c++) { const an = -Math.PI / 2 + c * Math.PI / 5, rr = c % 2 ? r2 : r1; c ? ctx.lineTo(scx + Math.cos(an) * rr, scy + Math.sin(an) * rr) : ctx.moveTo(scx + Math.cos(an) * rr, scy + Math.sin(an) * rr); }
      ctx.closePath(); ctx.fill(); ctx.restore();
    } else if (st === 10) {
      const vx = W * (portrait ? .5 : .34), vy = H * (portrait ? .30 : .40), bottom = H * .66, mr = base * .7;
      ctx.lineWidth = Math.max(2, base * .005);
      for (let k = 0; k < 4; k++) { const f = (phase * 2 + k / 4) % 1; ctx.strokeStyle = rgba(k % 2 ? c2 : c1, a * .65 * (1 - f)); ctx.beginPath(); ctx.arc(vx, vy, mr * f, 200 * Math.PI / 180, 340 * Math.PI / 180); ctx.stroke(); }
      ctx.lineWidth = Math.max(2, base * .004); ctx.strokeStyle = rgba(c1, a * .4);
      ctx.beginPath(); ctx.moveTo(vx, vy); ctx.lineTo(vx - W * .55, bottom); ctx.moveTo(vx, vy); ctx.lineTo(vx + W * .55, bottom); ctx.stroke();
      for (let k = 0; k < 6; k++) {
        const f = (phase * 3 + k / 6) % 1, t = f * f, y = vy + (bottom - vy) * t, len = (bottom - vy) * .1 * (.3 + t), half = base * .003 * (.6 + 4 * t);
        ctx.fillStyle = rgba(c2, a * .55 * Math.min(1, f * 3)); ctx.fillRect(vx - half, y, half * 2, len);
      }
    }
    particles(i, a);
  }
  function crescent(a, col, bob, gl) {
    const cr = portrait ? Math.min(W, H) * .13 : H * .15, cx = portrait ? W * .8 : W * .82, cy = portrait ? H * .2 : H * .27;
    const cres = crescentPath(cx, cy, cr);
    ctx.save(); ctx.translate(0, bob);
    const m = col.match(/\d+/g);
    for (let k = 3; k >= 1; k--) { ctx.save(); ctx.translate(cx, cy); ctx.scale(1 + .08 * k, 1 + .08 * k); ctx.translate(-cx, -cy); cres(`rgba(${m[0]},${m[1]},${m[2]},${a * gl * (4 - k)})`); ctx.restore(); }
    cres(`rgba(${m[0]},${m[1]},${m[2]},${a * .95})`); ctx.restore();
  }

  function drawScene(i, alpha, slide) {
    if (alpha <= .01) return;
    let a = alpha;
    // colour wash
    const gx = W * (portrait ? .5 : .28) + drift * W * .04, gy = H * .26;
    let g = ctx.createRadialGradient(gx, gy, 0, gx, gy, glowR);
    g.addColorStop(0, rgba(C1[i], 150 / 255)); g.addColorStop(.5, rgba(C1[i], 60 / 255)); g.addColorStop(1, rgba(C1[i], 0));
    ctx.globalAlpha = a; ctx.fillStyle = g; ctx.fillRect(0, 0, W, H);
    const hx = W * (portrait ? .85 : .88) - drift * W * .04, hy = H * .18;
    g = ctx.createRadialGradient(hx, hy, 0, hx, hy, glowR * .8);
    g.addColorStop(0, rgba(C2[i], 110 / 255)); g.addColorStop(1, rgba(C2[i], 0));
    ctx.fillStyle = g; ctx.fillRect(0, 0, W, H); ctx.globalAlpha = 1;

    let cb = (portrait && ok(img.p[i])) ? img.p[i] : (ok(img.l[i]) ? img.l[i] : null), ca = 1;
    if (!cb && S[i].bg) { /* still loading */ cb = null; ca = 0; }
    if (!cb && !S[i].bg) { cb = (portrait ? img.liveP[i] : img.liveL[i]) || null; ca = liveA[i]; }
    if (!cb || ca < 1) {
      if (S[i].style > 0) motif(i, a);
      else if (ok(img.tile[i])) {
        const t = img.tile[i], aw = portrait ? W * .8 : W * .4, ah = aw * t.height / t.width;
        const cx = W * (portrait ? .5 : .3) + drift * W * .015 + slide * W * .04, cy = H * (portrait ? .3 : .36);
        ctx.globalAlpha = a * .3; ctx.drawImage(t, cx - aw / 2, cy - ah / 2, aw, ah); ctx.globalAlpha = 1;
      }
    }
    if (cb) {
      const sc = Math.max(W / cb.width, H / cb.height);
      ctx.globalAlpha = a * ca; ctx.drawImage(cb, (W - cb.width * sc) / 2, (H - cb.height * sc) / 2, cb.width * sc, cb.height * sc);
      ctx.fillStyle = `rgba(0,0,0,${.35})`; ctx.globalAlpha = a * ca; ctx.fillRect(0, 0, W, H); ctx.globalAlpha = 1;
      a = a * (1 - ca); if (a <= .012) return;
    } else if (S[i].bg && ca === 0) { return; }
    heroText(i, a, slide);
  }

  function heroText(i, a, slide) {
    const name = S[i].name, host = S[i].host, label = 'فتح';
    const shift = slide * W * .05;
    let ts = portrait ? Math.min(W * .12, H * .06) : H * .085;
    const maxW = portrait ? W * .86 : W * .36;
    ctx.font = `700 ${ts}px "Segoe UI",Tahoma,Arial,sans-serif`;
    let tw = ctx.measureText(name).width;
    if (tw > maxW) { ts *= maxW / tw; ctx.font = `700 ${ts}px "Segoe UI",Tahoma,Arial,sans-serif`; tw = ctx.measureText(name).width; }
    const hs = portrait ? Math.min(W * .045, H * .022) : H * .032;
    const pillH = portrait ? Math.min(W * .11, H * .05) : H * .065;
    ctx.font = `700 ${pillH * .44}px "Segoe UI",Tahoma,Arial,sans-serif`;
    const pw = ctx.measureText(label).width, pillW = pillH * .45 + pillH * .42 + pillH * .3 + pw + pillH * .55;
    const titleY = portrait ? H * .37 : H * .43, hostY = titleY + hs * 1.9, pillTop = hostY + hs * 1.2;
    const left = portrait ? W / 2 - Math.max(tw, pillW) / 2 : W * .07;
    ctx.globalAlpha = a; ctx.textAlign = 'left'; ctx.textBaseline = 'alphabetic';
    ctx.font = `700 ${ts}px "Segoe UI",Tahoma,Arial,sans-serif`;
    ctx.shadowColor = rgba(C1[i], 200 / 255); ctx.shadowBlur = ts * .35; ctx.fillStyle = '#fff';
    ctx.fillText(name, (portrait ? W / 2 - tw / 2 : left) + shift, titleY); ctx.shadowBlur = 0;
    ctx.font = `400 ${hs}px "Segoe UI",Tahoma,Arial,sans-serif`; ctx.fillStyle = 'rgba(227,217,245,.85)';
    const hw = ctx.measureText(host).width; ctx.fillText(host, (portrait ? W / 2 - hw / 2 : left) + shift, hostY);
    const px0 = (portrait ? W / 2 - pillW / 2 : left) + shift;
    ctx.fillStyle = 'rgba(255,255,255,.95)'; ctx.beginPath();
    if (ctx.roundRect) ctx.roundRect(px0, pillTop, pillW, pillH, pillH / 2); else ctx.rect(px0, pillTop, pillW, pillH); ctx.fill();
    const ix = px0 + pillH * .45, iy = pillTop + pillH / 2, is = pillH * .21;
    ctx.fillStyle = '#15101F'; ctx.beginPath(); ctx.moveTo(ix, iy - is); ctx.lineTo(ix + is * 1.5, iy); ctx.lineTo(ix, iy + is); ctx.closePath(); ctx.fill();
    ctx.font = `700 ${pillH * .44}px "Segoe UI",Tahoma,Arial,sans-serif`; ctx.fillText(label, ix + pillH * .72, iy + pillH * .44 * .35);
    ctx.globalAlpha = 1;
  }

  function frame(ts) {
    requestAnimationFrame(frame);
    if (document.hidden || document.body.classList.contains('site-open')) return;
    if (!W || cv.clientWidth !== W || cv.clientHeight !== H) resize();
    if (!W) return;
    drift = (() => { const t = (ts % 14000) / 7000; return (t < 1 ? t : 2 - t) * 2 - 1; })();
    phase = (ts % 18000) / 18000;
    if (prev >= 0) { const t = Math.min(1, (ts - fadeT0) / 460); fade = 1 - Math.pow(1 - t, 2.8); if (t >= 1) { prev = -1; fade = 1; } }
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0); ctx.clearRect(0, 0, W, H); ctx.fillStyle = '#05030C'; ctx.fillRect(0, 0, W, H);
    if (prev >= 0) drawScene(prev, 1 - fade, -dir * fade);
    drawScene(cur, prev >= 0 ? fade : 1, dir * (1 - fade));
    const sg = ctx.createLinearGradient(0, H * .4, 0, H); sg.addColorStop(0, 'rgba(0,0,0,0)'); sg.addColorStop(1, 'rgba(0,0,0,.69)');
    ctx.fillStyle = sg; ctx.fillRect(0, H * .4, W, H * .6);
  }

  window.Hero = {
    setIndex(i, animate) {
      if (i < 0 || i >= N || i === cur) return;
      dir = i > cur ? 1 : -1;
      ensure(i); ensure(i - 1); ensure(i + 1);
      if (animate) { prev = cur; fadeT0 = performance.now(); fade = 0; } else { prev = -1; fade = 1; }
      cur = i;
    },
    setLive,
    ensure,
  };
  ensure(0); ensure(1);
  requestAnimationFrame(frame);
})();
