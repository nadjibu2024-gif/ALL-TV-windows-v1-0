'use strict';
// Bridge between the shell page (home screen, profiles, TV lists ...) and the main process
const { contextBridge, ipcRenderer } = require('electron');

const on = (ch, cb) => { const f = (e, ...a) => cb(...a); ipcRenderer.on(ch, f); return () => ipcRenderer.removeListener(ch, f); };

contextBridge.exposeInMainWorld('alltv', {
  isDesktop: true,
  openSite: (req) => ipcRenderer.invoke('site:open', req),
  closeSite: () => ipcRenderer.invoke('site:close'),
  siteBack: () => ipcRenderer.invoke('site:back'),
  siteReload: () => ipcRenderer.invoke('site:reload'),
  setAds: (on_) => ipcRenderer.invoke('site:ads', on_),
  onSiteState: (cb) => on('site:state', cb),
  onSiteCmd: (cb) => on('site:cmd', cb),
  onSiteClosed: (cb) => on('site:closed', cb),
  onFullscreen: (cb) => on('app:fullscreen', cb),
  quote: (s) => ipcRenderer.invoke('net:quote', s),
  fetchText: (url, opts) => ipcRenderer.invoke('net:text', url, opts),
  playlist: (kind, force) => ipcRenderer.invoke('tv:playlist', kind, force),
  streamHeaders: (h) => ipcRenderer.invoke('tv:headers', h),
  snapList: () => ipcRenderer.invoke('snap:list'),
  snapStart: (names, portrait) => ipcRenderer.invoke('snap:start', names, portrait),
  onSnap: (cb) => on('snap:ready', cb),
  toggleFullscreen: () => ipcRenderer.invoke('app:fullscreen'),
  isFullscreen: () => ipcRenderer.invoke('app:isFullscreen'),
  quit: () => ipcRenderer.invoke('app:quit'),
  openExternal: (u) => ipcRenderer.invoke('app:external', u),
  cast: (mode) => ipcRenderer.invoke('app:cast', mode),
});
