'use strict';
// Port of SandboxFix.java: Algeria TV's pages (and the elahmad player frames) lose any iframe "sandbox" restriction
const SCRIPT = String.raw`<script>(function(){'use strict';try{
var clean=function(root){try{if(!root)return;
if(root.nodeType===1&&root.tagName==='IFRAME')root.removeAttribute('sandbox');
if(root.querySelectorAll){var a=root.querySelectorAll('iframe[sandbox]');for(var i=0;i<a.length;i++)a[i].removeAttribute('sandbox');}}catch(e){}};
var ep=Element.prototype,oldSet=ep.setAttribute,oldSetNS=ep.setAttributeNS;
ep.setAttribute=function(n,v){if(this.tagName==='IFRAME'&&String(n).toLowerCase()==='sandbox')return;return oldSet.call(this,n,v);};
ep.setAttributeNS=function(ns,n,v){if(this.tagName==='IFRAME'&&String(n).toLowerCase()==='sandbox')return;return oldSetNS.call(this,ns,n,v);};
var desc=Object.getOwnPropertyDescriptor(HTMLIFrameElement.prototype,'sandbox');
if(desc&&desc.get)try{Object.defineProperty(HTMLIFrameElement.prototype,'sandbox',{configurable:true,enumerable:desc.enumerable,get:function(){return desc.get.call(this);},set:function(v){}});}catch(e){}
var wrap=function(name){var old=ep[name];if(!old)return;ep[name]=function(node){clean(node);return old.apply(this,arguments);};};
wrap('appendChild');wrap('insertBefore');wrap('replaceChild');
var RX=/(<iframe\b[^>]*?)\s+sandbox(\s*=\s*("[^"]*"|'[^']*'|[^\s>]+))?/ig;
var ih=Object.getOwnPropertyDescriptor(ep,'innerHTML');
if(ih&&ih.get&&ih.set)try{Object.defineProperty(ep,'innerHTML',{configurable:true,enumerable:ih.enumerable,get:function(){return ih.get.call(this);},set:function(v){if(typeof v==='string')v=v.replace(RX,'$1');return ih.set.call(this,v);}});}catch(e){}
var oi=ep.insertAdjacentHTML;if(oi)ep.insertAdjacentHTML=function(pos,html){if(typeof html==='string')html=html.replace(RX,'$1');return oi.call(this,pos,html);};
var ow=Document.prototype.write,owl=Document.prototype.writeln;
if(ow)Document.prototype.write=function(){var a=[].slice.call(arguments);for(var i=0;i<a.length;i++)if(typeof a[i]==='string')a[i]=a[i].replace(RX,'$1');return ow.apply(this,a);};
if(owl)Document.prototype.writeln=function(){var a=[].slice.call(arguments);for(var i=0;i<a.length;i++)if(typeof a[i]==='string')a[i]=a[i].replace(RX,'$1');return owl.apply(this,a);};
clean(document);
if(window.MutationObserver&&document.documentElement){new MutationObserver(function(ms){for(var j=0;j<ms.length;j++){
if(ms[j].type==='attributes'&&ms[j].target.tagName==='IFRAME')ms[j].target.removeAttribute('sandbox');
else for(var k=0;k<ms[j].addedNodes.length;k++)clean(ms[j].addedNodes[k]);}}).observe(document.documentElement,{childList:true,subtree:true,attributes:true,attributeFilter:['sandbox']});}
}catch(e){}})();</script><script>(function(){try{
var re=/(Please remove it to continue|is not allowed on)/i;var done=0;
function hideCard(){try{var b=document.body;if(!b||done>400){return;}done++;
var t=b.innerText||'';if(!/sandbox/i.test(t)||!re.test(t)){return;}
var w=document.createTreeWalker(b,NodeFilter.SHOW_TEXT,null);var n;
while((n=w.nextNode())){if(re.test(n.nodeValue||'')){var e=n.parentNode;
while(e&&e.parentNode&&e.parentNode!==b&&e.parentNode!==document.documentElement){var q=e.parentNode;
if(q.querySelector('video,iframe,canvas,object,embed')||((q.innerText||'').length>600)){break;}e=q;}
if(e&&e!==b&&e.style){e.style.setProperty('display','none','important');}break;}}}catch(x){}}
var tm=0;var go=function(){if(tm){return;}tm=setTimeout(function(){tm=0;hideCard();},200);};
if(window.MutationObserver&&document.documentElement){new MutationObserver(go).observe(document.documentElement,{childList:true,subtree:true,characterData:true});}
setInterval(hideCard,1000);}catch(e){}})();</script>`;

const IFRAME_TAG = /<iframe\b[^>]*>/gi;
const SANDBOX_ATTR = /\s+sandbox(\s*=\s*("[^"]*"|'[^']*'|[^\s>]+))?/gi;

function wantsHost(host) {
  if (!host) return false;
  const h = host.toLowerCase();
  return h === 'algeria-tv.com' || h.endsWith('.algeria-tv.com') || h === 'catsbengal.com' || h.endsWith('.catsbengal.com');
}
function wantsFrameHost(host) {
  if (!host) return false;
  const h = host.toLowerCase();
  return wantsHost(h) || h === 'elahmad.ru' || h.endsWith('.elahmad.ru') || h === 'elahmad.com' || h.endsWith('.elahmad.com');
}

function clean(html) {
  if (!html) return html;
  const out = html.replace(IFRAME_TAG, (tag) => tag.replace(SANDBOX_ATTR, ''));
  const lower = out.toLowerCase();
  let head = lower.indexOf('<head');
  if (head >= 0) {
    const end = lower.indexOf('>', head);
    if (end >= 0) return out.substring(0, end + 1) + SCRIPT + out.substring(end + 1);
  }
  const ht = lower.indexOf('<html');
  if (ht >= 0) {
    const end = lower.indexOf('>', ht);
    if (end >= 0) return out.substring(0, end + 1) + SCRIPT + out.substring(end + 1);
  }
  return SCRIPT + out;
}

module.exports = { wantsHost, wantsFrameHost, clean };
