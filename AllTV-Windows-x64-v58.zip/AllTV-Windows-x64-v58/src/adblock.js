'use strict';
// Port of AdBlocker.java (host / address based ad and pop-up blocker). Lists come from data/adlists.json
const L = require('./data/adlists.json');

const SET = new Set(L.HOSTS);
const CACHE = new Map();

function check(host) {
  let h = host.toLowerCase();
  if (h.startsWith('ads.') || h.startsWith('adserver.') || h.startsWith('adserv.') ||
      h.startsWith('popunder.') || h.startsWith('banners.') || h.startsWith('adsx.')) return true;
  for (const w of L.HOST_WORDS) if (h.indexOf(w) >= 0) return true;
  for (;;) {
    if (SET.has(h)) return true;
    const dot = h.indexOf('.');
    if (dot < 0 || h.indexOf('.', dot + 1) < 0) return false;
    h = h.substring(dot + 1);
  }
}

function isBlocked(host) {
  if (!host) return false;
  const k = CACHE.get(host);
  if (k !== undefined) return k;
  const r = check(host);
  if (CACHE.size > 4000) CACHE.clear();
  CACHE.set(host, r);
  return r;
}

function hasWord(url, words) {
  const u = url.toLowerCase();
  for (const w of words) if (u.indexOf(w) >= 0) return true;
  return false;
}

function isBlockedUrl(url, host) {
  if (isBlocked(host)) return true;
  if (!url) return false;
  return hasWord(url, L.PATH_WORDS);
}

function isBlockedUrlLight(url, host) {
  if (isBlocked(host)) return true;
  if (!url) return false;
  return hasWord(url, L.PATH_WORDS_LIGHT);
}

function baseDomain(host) {
  if (!host) return '';
  const h = host.toLowerCase();
  const parts = h.split('.');
  const n = parts.length;
  if (n <= 2) return h;
  const last = parts[n - 1];
  const prev = parts[n - 2];
  const second = last.length === 2 && ['co', 'com', 'org', 'net', 'gov', 'ac'].includes(prev);
  const keep = second ? 3 : 2;
  return parts.slice(n - keep).join('.');
}

// Strict rule for a plain list page (TBCPL): a script or a frame that comes from another site is dropped
function isStrayThirdParty(url, host, pageBase, accept) {
  if (!url || !host || !pageBase) return false;
  if (baseDomain(host) === pageBase) return false;
  const h = host.toLowerCase();
  for (const k of L.HELPERS) if (h === k || h.endsWith('.' + k)) return false;
  const u = url.toLowerCase();
  const q = u.indexOf('?');
  const path = q >= 0 ? u.substring(0, q) : u;
  const a = (accept || '').toLowerCase();
  const frame = a.indexOf('text/html') >= 0;
  const script = path.endsWith('.js') || path.endsWith('.mjs') || path.endsWith('.php') || a.indexOf('javascript') >= 0;
  const media = ['.png', '.jpg', '.jpeg', '.webp', '.svg', '.gif', '.ico', '.css', '.woff', '.woff2', '.ttf', '.json']
    .some((e) => path.endsWith(e)) || a.indexOf('image/') === 0 || a.indexOf('text/css') >= 0;
  return (frame || script) && !media;
}

// Betting / casino landing pages and ad search pages: never opened from "Your SPACE"
function isAdLanding(url) {
  try {
    const u = new URL(url);
    const h = u.hostname.toLowerCase();
    const words = ['1xbet', '1xlite', '1xbit', 'melbet', 'betwinner', 'linebet', 'mostbet', 'parimatch', '22bet',
      'betway', 'casino', 'bet365', 'pinup', 'pin-up', '1win', 'stake.com', 'slotv', 'vulkan', 'betano', 'betsson'];
    for (const w of words) if (h.includes(w)) return true;
    if ((h.startsWith('google.') || h.indexOf('.google.') >= 0) && u.pathname.startsWith('/search')) return true;
  } catch (e) { /* not an address */ }
  return false;
}

function isSocialUrl(url) {
  try {
    const b = baseDomain(new URL(url).hostname);
    return ['discord.com', 'discord.gg', 'discordapp.com', 't.me', 'telegram.me', 'telegram.org', 'reddit.com',
      'redd.it', 'facebook.com', 'instagram.com', 'twitter.com', 'x.com'].includes(b);
  } catch (e) { return false; }
}

module.exports = { isBlocked, isBlockedUrl, isBlockedUrlLight, isStrayThirdParty, baseDomain, isAdLanding, isSocialUrl };
