'use strict';
// Runs inside every site (and its frames) before the page's own scripts:
//  - the site sees an ordinary Chrome browser (no "Electron" traces)
//  - taps of the person are reported (an ad redirect that nobody tapped is stopped)
//  - the ad / pop-up cleaner of the Android app is started at once
const { ipcRenderer, webFrame } = require('electron');

try {
  const isTop = window === window.top;
  const tap = () => { try { ipcRenderer.send('site:tap'); } catch (e) { /* ignore */ } };
  window.addEventListener('pointerdown', tap, true);
  window.addEventListener('keydown', (e) => { if (e.key === 'Enter' || e.key === ' ') tap(); }, true);

  // look like a normal Chrome
  try {
    if (navigator.webdriver) Object.defineProperty(Navigator.prototype, 'webdriver', { get: () => false, configurable: true });
  } catch (e) { /* ignore */ }
  try { if (!window.chrome) window.chrome = { runtime: {} }; } catch (e) { /* ignore */ }

  if (isTop) {
    const js = ipcRenderer.sendSync('site:cfg');
    if (js) {
      let ran = false;
      try { (0, eval)(js); ran = true; } catch (e) { /* page policy may refuse eval */ }
      if (!ran) { try { webFrame.executeJavaScript(js); } catch (e) { /* ignore */ } }
    }
  }
} catch (e) { /* never break the page */ }
