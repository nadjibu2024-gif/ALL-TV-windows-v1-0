'use strict';
const path = require('path');
const fs = require('fs');
const { app, BrowserWindow, WebContentsView, session, ipcMain, shell, net, Menu, nativeImage, dialog } = require('electron');
const adb = require('./adblock');
const sandboxfix = require('./sandboxfix');
const PAGEJS = require('./data/pagejs.json');
const SITES = require('./data/sites.json');

// ---------------------------------------------------------------------------------------------
// constants
// ---------------------------------------------------------------------------------------------
const BAR_H = 44;                       // height of the site bar (drawn by the shell page)
const SITE_PARTITION = 'persist:alltv'; // cookies / logins of the sites survive restarts
const ALGERIA_PARTITION = 'persist:alltv-algeria';
const SNAP_PARTITION = 'alltv-snap';
const TV_UA = 'Mozilla/5.0 (SMART-TV; LINUX; Tizen 6.0) AppleWebKit/537.36 (KHTML, like Gecko) 76.0.3809.146/6.0 TV Safari/537.36';
const MARKET_UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36';
const CHROME_UA = `Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/${process.versions.chrome} Safari/537.36`;

app.commandLine.appendSwitch('autoplay-policy', 'no-user-gesture-required');
app.commandLine.appendSwitch('disable-features', 'HardwareMediaKeyHandling,MediaSessionService');
app.commandLine.appendSwitch('enable-features', 'VaapiVideoDecoder');
app.commandLine.appendSwitch('ignore-gpu-blocklist');
app.commandLine.appendSwitch('enable-gpu-rasterization');

if (!app.requestSingleInstanceLock()) { app.quit(); }

let win = null;
let siteState = null;       // the site that is open right now
let htmlFullscreen = false;
let adBlockEnabled = true;
let streamHeaders = null;   // {referrer, userAgent} while a TV channel plays in the shell

const userData = () => app.getPath('userData');
const log = (...a) => { try { console.log('[alltv]', ...a); } catch (e) { /* ignore */ } };

function siteByName(n) { return SITES.find((s) => s.name === n); }

// ---------------------------------------------------------------------------------------------
// per site behaviour (same rules as the Android app)
// ---------------------------------------------------------------------------------------------
function profile(name, url) {
  const u = url || '';
  const kids = name === 'Kids Space';
  const kidoodle = kids && /kidoodle\.tv|kids-tube\.com|toongoggles\.com|nahlaaa\.com/.test(u);
  const tv = !!(siteByName(name) && siteByName(name).tv);
  const atlantic = name === 'Atlantic';
  const conan = name === 'Conan Arabi';
  const soft = name === 'SportsBite' || name === 'Streamex';
  let pageJs = PAGEJS.PAGE_JS;
  if (name === 'Algeria TV') pageJs = PAGEJS.PAGE_JS_LITE;
  else if (soft) pageJs = name === 'SportsBite' ? PAGEJS.PAGE_JS_LL24 : PAGEJS.PAGE_JS_LL24_ADS;
  let pre = '';
  if (atlantic) pre = PAGEJS.ATLANTIC_SHIM_JS;
  if (kids && /kidoodle\.tv|kids-tube\.com|nahlaaa\.com/.test(u)) {
    const dark = /kids-tube\.com|nahlaaa\.com/.test(u);
    pre = (dark ? 'window.__kgDark=1;' : '') + PAGEJS.KIDS_GLASS_JS;
  }
  return {
    name, tv, soft, atlantic, conan, kids,
    adAllowed: !tv && !atlantic && !kidoodle && !conan,
    directory: name === 'TBCPL' ? 'tbcpl.lol' : (name === 'Your SPACE' ? 'allsitehub.site' : ''),
    algeria: name === 'Algeria TV',
    pageJs, pre,
    ua: tv ? TV_UA : CHROME_UA,
  };
}

// ---------------------------------------------------------------------------------------------
// window
// ---------------------------------------------------------------------------------------------
function createWindow() {
  win = new BrowserWindow({
    width: 1280, height: 760, minWidth: 720, minHeight: 480,
    backgroundColor: '#05030C',
    title: 'All TV',
    icon: path.join(__dirname, '..', 'build', 'icon.png'),
    show: false,
    autoHideMenuBar: true,
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true, sandbox: true, nodeIntegration: false,
      backgroundThrottling: false, spellcheck: false,
      autoplayPolicy: 'no-user-gesture-required',
    },
  });
  Menu.setApplicationMenu(null);
  win.once('ready-to-show', () => { win.maximize(); win.show(); });
  win.loadFile(path.join(__dirname, 'renderer', 'index.html'));
  win.on('resize', layoutSite);
  win.on('maximize', layoutSite);
  win.on('unmaximize', layoutSite);
  win.on('enter-full-screen', () => { layoutSite(); send('app:fullscreen', true); });
  win.on('leave-full-screen', () => { layoutSite(); send('app:fullscreen', false); });
  win.on('app-command', (e, cmd) => {
    if (cmd === 'browser-backward') { send('site:cmd', 'back'); }
    else if (cmd === 'browser-forward' && siteState && siteState.view.webContents.navigationHistory.canGoForward()) {
      siteState.view.webContents.navigationHistory.goForward();
    }
  });
  win.on('closed', () => { win = null; });
  win.webContents.setWindowOpenHandler(() => ({ action: 'deny' }));
  win.webContents.on('will-navigate', (e, url) => { if (!url.startsWith('file://')) e.preventDefault(); });
}

function send(channel, ...args) {
  try { if (win && !win.isDestroyed()) win.webContents.send(channel, ...args); } catch (e) { /* closed */ }
}

function layoutSite() {
  if (!win || !siteState) return;
  const [w, h] = win.getContentSize();
  siteState.view.setBounds(htmlFullscreen
    ? { x: 0, y: 0, width: w, height: h }
    : { x: 0, y: BAR_H, width: w, height: Math.max(0, h - BAR_H) });
}

// ---------------------------------------------------------------------------------------------
// sessions: ad blocking, headers, permissions
// ---------------------------------------------------------------------------------------------
const configured = new Set();
function configureSession(ses, kind) {
  if (configured.has(ses)) return;
  configured.add(ses);
  ses.setUserAgent(CHROME_UA);
  ses.setPermissionRequestHandler((wc, permission, cb) => {
    // nothing that could be used for push adverts or tracking
    cb(permission === 'fullscreen' || permission === 'clipboard-sanitized-write' || permission === 'media' || permission === 'pointerLock');
  });
  ses.setPermissionCheckHandler((wc, permission) => ['fullscreen', 'clipboard-sanitized-write', 'media'].includes(permission));
  ses.on('will-download', (e) => e.preventDefault());
  ses.webRequest.onBeforeRequest({ urls: ['http://*/*', 'https://*/*', 'ws://*/*', 'wss://*/*'] }, (details, cb) => {
    try { cb(filterRequest(details, kind) ? { cancel: true } : {}); } catch (e) { cb({}); }
  });
}

function acceptFor(rt) {
  if (rt === 'subFrame') return 'text/html';
  if (rt === 'script') return 'application/javascript';
  if (rt === 'image') return 'image/webp';
  if (rt === 'stylesheet') return 'text/css';
  return '';
}

function filterRequest(d, kind) {
  const st = kind === 'snap' ? snapState : siteState;
  if (!st || !st.blocking) return false;
  if (kind !== 'snap' && (!st.view || d.webContentsId !== st.view.webContents.id)) return false;
  if (st.relax >= 2) return false;
  let u;
  try { u = new URL(d.url); } catch (e) { return false; }
  if (u.protocol !== 'http:' && u.protocol !== 'https:') return false;
  const host = u.hostname;
  const main = d.resourceType === 'mainFrame';
  let hit = adb.isBlocked(host);
  if (!hit && !main && st.relax < 1) {
    const own = adb.baseDomain(host) === st.curBase || sandboxfix.wantsFrameHost(host);
    if (!own) hit = st.soft ? adb.isBlockedUrlLight(d.url, host) : adb.isBlockedUrl(d.url, host);
  }
  if (!hit && !main && st.relax < 1 && st.prof && st.prof.directory === 'tbcpl.lol' && st.curBase === 'tbcpl.lol') {
    hit = adb.isStrayThirdParty(d.url, host, st.curBase, acceptFor(d.resourceType));
  }
  return hit;
}

let snapState = null;

// Shell page: let video streams of any server play (CORS) and send the headers a channel asks for
function configureShellSession() {
  const ses = session.defaultSession;
  ses.webRequest.onBeforeSendHeaders({ urls: ['http://*/*', 'https://*/*'] }, (details, cb) => {
    const h = details.requestHeaders;
    if (streamHeaders && win && details.webContentsId === win.webContents.id) {
      if (streamHeaders.userAgent) h['User-Agent'] = streamHeaders.userAgent;
      if (streamHeaders.referrer) {
        h['Referer'] = streamHeaders.referrer;
        try { h['Origin'] = new URL(streamHeaders.referrer).origin; } catch (e) { /* ignore */ }
      }
    }
    cb({ requestHeaders: h });
  });
  ses.webRequest.onHeadersReceived({ urls: ['http://*/*', 'https://*/*'] }, (details, cb) => {
    const h = details.responseHeaders || {};
    for (const k of Object.keys(h)) {
      const lk = k.toLowerCase();
      if (lk === 'access-control-allow-origin' || lk === 'access-control-allow-headers' || lk === 'access-control-allow-methods') delete h[k];
    }
    h['Access-Control-Allow-Origin'] = ['*'];
    h['Access-Control-Allow-Headers'] = ['*'];
    h['Access-Control-Allow-Methods'] = ['GET, HEAD, OPTIONS'];
    cb({ responseHeaders: h });
  });
}

// ---------------------------------------------------------------------------------------------
// opening a site inside the app
// ---------------------------------------------------------------------------------------------
function currentBaseOf(url) {
  try { return adb.baseDomain(new URL(url).hostname); } catch (e) { return ''; }
}

function openSite(req) {
  closeSite(true);
  const prof = profile(req.name, req.url);
  const partition = prof.algeria ? ALGERIA_PARTITION : SITE_PARTITION;
  const ses = session.fromPartition(partition);
  configureSession(ses, 'site');
  if (prof.algeria) installSandboxHandler(ses);

  const view = new WebContentsView({
    webPreferences: {
      partition,
      preload: path.join(__dirname, 'site-preload.js'),
      contextIsolation: false, sandbox: true, nodeIntegration: false, nodeIntegrationInSubFrames: true,
      backgroundThrottling: false, spellcheck: false, webSecurity: true,
      autoplayPolicy: 'no-user-gesture-required', enableWebSQL: false,
    },
  });
  const wc = view.webContents;
  view.setBackgroundColor('#000000');
  wc.setUserAgent(prof.ua);
  wc.setAudioMuted(false);

  const st = {
    site: req.name, startUrl: req.url, view, prof,
    blocking: adBlockEnabled && prof.adAllowed,
    relax: 0, soft: prof.soft,
    curBase: currentBaseOf(req.url),
    tapAt: 0, settledAt: 0, netRetry: 0, ladder: 0, probeTimer: null, loading: false,
    closed: false,
  };
  siteState = st;
  htmlFullscreen = false;
  win.contentView.addChildView(view);
  layoutSite();

  hookWebContents(st);
  wc.loadURL(req.url, { userAgent: prof.ua }).catch(() => { /* handled by did-fail-load */ });
  wc.focus();
  send('site:state', { loading: true, title: req.name, canGoBack: false, url: req.url });
}

function closeSite(silent) {
  const st = siteState;
  if (!st) return;
  siteState = null;
  st.closed = true;
  clearTimeout(st.probeTimer);
  htmlFullscreen = false;
  if (win && win.isFullScreen() && st.fsByHtml) win.setFullScreen(false);
  try { win.contentView.removeChildView(st.view); } catch (e) { /* gone */ }
  try { st.view.webContents.setAudioMuted(true); st.view.webContents.close({ waitForBeforeUnload: false }); } catch (e) { /* gone */ }
  if (!silent) send('site:closed');
}

function installSandboxHandler(ses) {
  if (ses.__sandboxHandler) return;
  ses.__sandboxHandler = true;
  ses.protocol.handle('https', async (request) => {
    try {
      const host = new URL(request.url).hostname;
      if (request.method === 'GET' && sandboxfix.wantsFrameHost(host) && (request.headers.get('accept') || '').toLowerCase().includes('text/html')) {
        const resp = await net.fetch(request, { bypassCustomProtocolHandlers: true });
        const ct = (resp.headers.get('content-type') || '').toLowerCase();
        if (resp.status === 200 && ct.includes('text/html')) {
          const html = sandboxfix.clean(await resp.text());
          const headers = new Headers(resp.headers);
          headers.delete('content-length'); headers.delete('content-encoding'); headers.delete('content-security-policy');
          headers.set('cache-control', 'no-store');
          return new Response(html, { status: 200, headers });
        }
        return resp;
      }
    } catch (e) { /* fail open */ }
    return net.fetch(request, { bypassCustomProtocolHandlers: true });
  });
}

function runPageJs(st, force) {
  if (!st || st.closed) return;
  const wc = st.view.webContents;
  if (wc.isDestroyed()) return;
  const url = wc.getURL();
  const onDir = st.prof.directory && st.curBase === st.prof.directory;
  // Your SPACE list page itself: only light fixes
  if (st.prof.name === 'Your SPACE' && onDir) { wc.executeJavaScript(PAGEJS.SPACE_FIX_JS, true).catch(() => {}); return; }
  if (st.prof.pre) wc.executeJavaScript(st.prof.pre, true).catch(() => {});
  if (!st.blocking || st.relax >= 1 && !force) return;
  if (st.relax >= 2) return;
  wc.executeJavaScript(st.prof.pageJs, true).catch(() => {});
}

function hookWebContents(st) {
  const wc = st.view.webContents;
  const rec = () => { st.tapAt = Date.now(); };
  const recent = () => Date.now() - st.tapAt < 4000;
  const isOther = (url) => {
    try {
      const b = adb.baseDomain(new URL(url).hostname);
      if (st.prof.directory && st.curBase) return b !== st.curBase;
      return b !== adb.baseDomain(new URL(st.startUrl).hostname);
    } catch (e) { return false; }
  };
  const settled = () => st.settledAt > 0 && Date.now() - st.settledAt > 2500;

  ipcMain.removeAllListeners('site:tap:' + wc.id);
  wc.ipc.on('site:tap', rec);

  // navigations of the main page: ad redirects (to another site nobody tapped) are stopped
  const guard = (e, url, isRedirect) => {
    if (!/^https?:/i.test(url)) { e.preventDefault(); return; }
    if (st.prof.name === 'Your SPACE' && ((st.curBase === 'allsitehub.site' && adb.isSocialUrl(url)) || adb.isAdLanding(url))) { e.preventDefault(); return; }
    if (st.blocking) {
      let host = '';
      try { host = new URL(url).hostname; } catch (er) { /* keep */ }
      if (adb.isBlocked(host)) { e.preventDefault(); return; }
      const tap = recent() || (st.prof.name === 'Your SPACE' && st.curBase === 'allsitehub.site' && recent());
      if (st.relax < 2 && !tap && isOther(url) && (!isRedirect || settled())) { e.preventDefault(); }
    }
  };
  wc.on('will-navigate', (e) => guard(e, e.url, false));
  wc.on('will-redirect', (e) => guard(e, e.url, true));

  // pop-ups never open; a tapped link that wants a new tab opens in the same view
  wc.setWindowOpenHandler((d) => {
    const url = d.url;
    if (!/^https?:/i.test(url)) return { action: 'deny' };
    let host = '';
    try { host = new URL(url).hostname; } catch (e) { return { action: 'deny' }; }
    if (st.blocking && adb.isBlocked(host)) return { action: 'deny' };
    if (st.prof.name === 'Your SPACE' && (adb.isSocialUrl(url) || adb.isAdLanding(url))) return { action: 'deny' };
    if (recent() && d.disposition !== 'background-tab' && (!st.blocking || !isOther(url) || st.prof.directory)) {
      setImmediate(() => { if (!wc.isDestroyed()) wc.loadURL(url).catch(() => {}); });
    }
    return { action: 'deny' };
  });

  wc.on('did-start-navigation', (e) => {
    if (e.isMainFrame && !e.isSameDocument) {
      try { st.curBase = adb.baseDomain(new URL(e.url).hostname) || st.curBase; } catch (er) { /* keep */ }
      st.settledAt = 0; st.loading = true;
      send('site:state', { loading: true, title: wc.getTitle() || st.site, canGoBack: wc.navigationHistory.canGoBack(), url: e.url });
    }
  });
  wc.on('dom-ready', () => runPageJs(st));
  wc.on('did-navigate-in-page', () => runPageJs(st));
  wc.on('did-finish-load', () => {
    st.loading = false; st.netRetry = 0;
    st.settledAt = Date.now();
    runPageJs(st);
    send('site:state', { loading: false, title: wc.getTitle() || st.site, canGoBack: wc.navigationHistory.canGoBack(), url: wc.getURL() });
    scheduleProbe(st, 8000);
  });
  wc.on('page-title-updated', (e, title) => send('site:state', { title: title || st.site, canGoBack: wc.navigationHistory.canGoBack(), loading: st.loading, url: wc.getURL() }));
  wc.on('did-fail-load', (e, code, desc, url, isMain) => {
    if (!isMain || code === -3) return;
    if (st.netRetry < 2) {
      st.netRetry++;
      setTimeout(() => { if (!st.closed && !wc.isDestroyed()) wc.loadURL(st.startUrl === url ? url : url).catch(() => {}); }, 1500 * st.netRetry);
    } else {
      showError(st, code === -6 || code === -2 ? 'err_site' : 'err_load', url);
    }
  });
  wc.on('render-process-gone', () => { if (!st.closed && !wc.isDestroyed()) setTimeout(() => wc.reload(), 600); });
  wc.on('enter-html-full-screen', () => {
    htmlFullscreen = true;
    if (win && !win.isFullScreen()) { st.fsByHtml = true; win.setFullScreen(true); }
    layoutSite();
  });
  wc.on('leave-html-full-screen', () => {
    htmlFullscreen = false;
    if (win && st.fsByHtml) { st.fsByHtml = false; win.setFullScreen(false); }
    layoutSite();
  });
  wc.on('before-input-event', (e, input) => {
    if (input.type !== 'keyDown') return;
    if (input.key === 'Enter' || input.key === ' ') rec();
    const key = input.key;
    if (key === 'F11') { e.preventDefault(); toggleFullscreen(); }
    else if (key === 'F5' || (input.control && key.toLowerCase() === 'r')) { e.preventDefault(); doReload(); }
    else if (input.alt && key === 'ArrowLeft') { e.preventDefault(); send('site:cmd', 'back'); }
    else if (input.alt && key === 'Home') { e.preventDefault(); send('site:cmd', 'home'); }
    else if (key === 'Escape' && !htmlFullscreen && !win.isFullScreen()) { e.preventDefault(); send('site:cmd', 'back'); }
  });
  wc.on('context-menu', (e) => e.preventDefault());
  wc.on('media-started-playing', () => { /* keep the screen awake is handled by Chromium */ });
}

function showError(st, key, url) {
  const msg = key === 'err_site'
    ? 'الموقع نفسه يرد بخطأ (404)، قد يكون العنوان تغيّر أو الموقع متوقف.'
    : 'تعذّر تحميل الصفحة، تحقق من الإنترنت.';
  const html = `<!doctype html><meta charset="utf-8"><body style="margin:0;background:#05030c;color:#fff;font-family:Segoe UI,Tahoma,sans-serif;display:flex;align-items:center;justify-content:center;height:100vh;text-align:center">
  <div><div style="font-size:64px">📡</div><p style="font-size:20px;max-width:560px;line-height:1.7;direction:rtl">${msg}</p>
  <button onclick="location.href=${JSON.stringify(url)}" style="margin-top:12px;background:#ff2d95;color:#fff;border:0;border-radius:24px;padding:12px 34px;font-size:16px;cursor:pointer">تحديث</button></div>`;
  st.view.webContents.loadURL('data:text/html;charset=utf-8,' + encodeURIComponent(html)).catch(() => {});
}

// blank page repair ladder: 1) no page cleaner / no address filter  2) reload without cache
function scheduleProbe(st, delay) {
  clearTimeout(st.probeTimer);
  if (st.prof.tv) return;
  st.probeTimer = setTimeout(async () => {
    if (st.closed || st !== siteState) return;
    const wc = st.view.webContents;
    if (wc.isDestroyed() || /^data:/.test(wc.getURL())) return;
    let v = 1;
    try { v = await wc.executeJavaScript(st.soft ? PAGEJS.LL_PROBE_JS : PAGEJS.BLANK_PROBE_JS, true); } catch (e) { return; }
    if (v === 0 && st.ladder < 2 && !st.loading) {
      st.ladder++;
      st.relax = st.ladder;
      log('blank page, repair step', st.ladder);
      if (st.ladder === 2) wc.reloadIgnoringCache(); else wc.reload();
    }
  }, delay);
}

function doReload() {
  const st = siteState; if (!st) return;
  const wc = st.view.webContents;
  if (/^data:/.test(wc.getURL())) wc.loadURL(st.startUrl).catch(() => {}); else wc.reload();
}

function toggleFullscreen() {
  if (!win) return;
  win.setFullScreen(!win.isFullScreen());
}

// ---------------------------------------------------------------------------------------------
// live pictures of the sites (hidden window -> picture of the real home page)
// ---------------------------------------------------------------------------------------------
const snapsDir = () => { const d = path.join(userData(), 'snaps'); fs.mkdirSync(d, { recursive: true }); return d; };
const CHALLENGE_JS = "(function(){try{var t=((document.body&&document.body.innerText)||'').slice(0,600).toLowerCase();return /verifying|just a moment|security verification|checking your browser|are you human|captcha/.test(t)?'1':'0';}catch(e){return '0';}})();";
let snapQueue = [];
let snapRunning = false;

function snapFile(key, portrait) { return path.join(snapsDir(), key + (portrait ? '_p2.jpg' : '_l2.jpg')); }

function snapList() {
  const out = [];
  for (const s of SITES) {
    const key = s.name.toLowerCase().replace(/ /g, '');
    for (const portrait of [false, true]) {
      const f = snapFile(key, portrait);
      if (fs.existsSync(f)) out.push({ name: s.name, portrait, file: f, mtime: fs.statSync(f).mtimeMs });
    }
  }
  return out;
}

function snapStart(names, portrait) {
  for (const n of names) if (!snapQueue.some((q) => q.name === n && q.portrait === portrait)) snapQueue.push({ name: n, portrait });
  if (!snapRunning) { snapRunning = true; snapNext(); }
}

function snapNext() {
  if (!snapQueue.length || !win) { snapRunning = false; snapState = null; return; }
  if (siteState) { snapRunning = false; snapQueue = []; snapState = null; return; }   // a site is open: try later
  const job = snapQueue.shift();
  const site = siteByName(job.name);
  if (!site) { snapNext(); return; }
  const key = site.name.toLowerCase().replace(/ /g, '');
  const W = job.portrait ? 900 : 1600, H = job.portrait ? 1600 : 900;
  const ses = session.fromPartition(SNAP_PARTITION);
  configureSession(ses, 'snap');
  const w = new BrowserWindow({
    width: W, height: H, show: false, useContentSize: true, frame: false,
    webPreferences: { partition: SNAP_PARTITION, sandbox: true, contextIsolation: true, backgroundThrottling: false, offscreen: false, autoplayPolicy: 'user-gesture-required' },
  });
  w.webContents.setAudioMuted(true);
  w.webContents.setUserAgent(CHROME_UA);
  snapState = { blocking: adBlockEnabled, relax: 0, soft: false, curBase: adb.baseDomain(site.host), view: null, prof: null };
  let done = false;
  const finish = (ok) => {
    if (done) return; done = true;
    clearTimeout(killer);
    try { w.destroy(); } catch (e) { /* gone */ }
    setTimeout(snapNext, 800);
  };
  const killer = setTimeout(() => finish(false), 45000);
  const shoot = async (tries) => {
    if (done || w.isDestroyed()) return;
    let ch = '0';
    try { ch = await w.webContents.executeJavaScript(CHALLENGE_JS, true); } catch (e) { /* ignore */ }
    if (ch === '1' && tries < 4) { setTimeout(() => shoot(tries + 1), 4500); return; }
    if (ch !== '1') {
      try {
        const img = await w.webContents.capturePage();
        const buf = img.toJPEG(88);
        if (!isBlank(img)) {
          fs.writeFileSync(snapFile(key, job.portrait), buf);
          send('snap:ready', { name: job.name, portrait: job.portrait, file: snapFile(key, job.portrait), mtime: Date.now() });
        }
      } catch (e) { /* keep the built-in backdrop */ }
    }
    finish(true);
  };
  w.webContents.on('did-finish-load', () => {
    if (adBlockEnabled) w.webContents.executeJavaScript(PAGEJS.COSMETIC_JS, true).catch(() => {});
    setTimeout(() => shoot(0), 6000);
  });
  w.webContents.setWindowOpenHandler(() => ({ action: 'deny' }));
  w.webContents.on('will-navigate', (e, url) => {
    try { if (!new URL(url).hostname.endsWith(site.host)) e.preventDefault(); } catch (er) { e.preventDefault(); }
  });
  w.loadURL(site.url).catch(() => finish(false));
}

function isBlank(img) {
  try {
    const { width, height } = img.getSize();
    const bm = img.toBitmap();
    let bright = 0, minL = 255, maxL = 0;
    for (let y = 1; y < 9; y++) for (let x = 1; x < 9; x++) {
      const px = Math.floor(x * width / 10), py = Math.floor(y * height / 10);
      const o = (py * width + px) * 4;
      const l = (bm[o] + bm[o + 1] + bm[o + 2]) / 3;
      minL = Math.min(minL, l); maxL = Math.max(maxL, l); if (l > 40) bright++;
    }
    return bright < 2 && (maxL - minL) < 25;
  } catch (e) { return false; }
}

// ---------------------------------------------------------------------------------------------
// network helpers for the shell (TV lists, markets, news)
// ---------------------------------------------------------------------------------------------
async function fetchBuf(url, { ua = MARKET_UA, timeout = 15000 } = {}) {
  const ctl = new AbortController();
  const t = setTimeout(() => ctl.abort(), timeout);
  try {
    const r = await net.fetch(url, { headers: { 'User-Agent': ua, Accept: '*/*' }, signal: ctl.signal, redirect: 'follow' });
    if (!r.ok) throw new Error('HTTP ' + r.status);
    return Buffer.from(await r.arrayBuffer());
  } finally { clearTimeout(t); }
}

const PLAYLISTS = {
  ara: { url: 'https://iptv-org.github.io/iptv/languages/ara.m3u', file: 'tv_ara.m3u' },
  world: { url: 'https://iptv-org.github.io/iptv/index.m3u', file: 'tv_world.m3u' },
  free: { url: 'https://raw.githubusercontent.com/Free-TV/IPTV/master/playlist.m3u8', file: 'tv_free.m3u8' },
};

async function getPlaylist(kind, force) {
  const p = PLAYLISTS[kind];
  if (!p) throw new Error('bad list');
  const f = path.join(userData(), p.file);
  let age = Infinity;
  try { age = Date.now() - fs.statSync(f).mtimeMs; } catch (e) { /* none */ }
  if (!force && age < 6 * 3600 * 1000) return fs.readFileSync(f, 'utf8');
  try {
    const buf = await fetchBuf(p.url, { timeout: 60000 });
    fs.writeFileSync(f, buf);
    return buf.toString('utf8');
  } catch (e) {
    if (age !== Infinity) return fs.readFileSync(f, 'utf8');
    throw e;
  }
}

// ---------------------------------------------------------------------------------------------
// IPC
// presses Win + <key> with PowerShell (no extra package needed)
function keyChord(vk, fallback) {
  const { execFile } = require('child_process');
  const ps = "Add-Type -Namespace W -Name K -MemberDefinition '[DllImport(\"user32.dll\")] public static extern void keybd_event(byte a,byte b,uint c,int d);';" +
    "[W.K]::keybd_event(0x5B,0,0,0);[W.K]::keybd_event(" + vk + ",0,0,0);[W.K]::keybd_event(" + vk + ",0,2,0);[W.K]::keybd_event(0x5B,0,2,0)";
  execFile('powershell.exe', ['-NoProfile', '-WindowStyle', 'Hidden', '-Command', ps], { windowsHide: true }, (err) => { if (err && fallback) fallback(); });
}
// ---------------------------------------------------------------------------------------------
function setupIpc() {
  ipcMain.handle('site:open', (e, req) => { openSite(req); });
  ipcMain.handle('site:close', () => { closeSite(false); });
  ipcMain.handle('site:back', () => {
    const st = siteState; if (!st) return false;
    const h = st.view.webContents.navigationHistory;
    if (h.canGoBack()) { h.goBack(); return true; }
    return false;
  });
  ipcMain.handle('site:reload', () => { doReload(); });
  ipcMain.handle('site:ads', (e, on) => {
    adBlockEnabled = !!on;
    const st = siteState;
    if (st) { st.blocking = adBlockEnabled && st.prof.adAllowed; st.relax = 0; st.ladder = 0; doReload(); }
  });
  ipcMain.handle('net:quote', async (e, symbol) => {
    const enc = encodeURIComponent(symbol);
    let data;
    try { data = await fetchBuf(`https://query1.finance.yahoo.com/v8/finance/chart/${enc}?interval=1m&range=1d`, { timeout: 12000 }); }
    catch (er) { data = await fetchBuf(`https://query2.finance.yahoo.com/v8/finance/chart/${enc}?interval=1m&range=1d`, { timeout: 12000 }); }
    const meta = JSON.parse(data.toString('utf8')).chart.result[0].meta;
    const price = meta.regularMarketPrice;
    let prev = meta.chartPreviousClose;
    if (!prev) prev = meta.previousClose;
    if (!(price > 0) || !(prev > 0)) throw new Error('no data');
    return [price, (price - prev) / prev * 100];
  });
  ipcMain.handle('net:text', async (e, url, opts) => (await fetchBuf(url, opts || {})).toString('utf8'));
  ipcMain.handle('tv:playlist', (e, kind, force) => getPlaylist(kind, force));
  ipcMain.handle('tv:headers', (e, h) => { streamHeaders = h && (h.referrer || h.userAgent) ? h : null; });
  ipcMain.handle('snap:list', () => snapList());
  ipcMain.handle('snap:start', (e, names, portrait) => snapStart(names, portrait));
  ipcMain.handle('app:fullscreen', () => { toggleFullscreen(); });
  ipcMain.handle('app:isFullscreen', () => !!(win && win.isFullScreen()));
  ipcMain.handle('app:quit', () => { app.quit(); });
  ipcMain.handle('app:external', (e, url) => { if (/^https?:\/\//i.test(url)) shell.openExternal(url); });
  ipcMain.handle('app:cast', (e, mode) => {
    const settings = () => shell.openExternal('ms-settings-connectabledevices:devicediscovery').catch(() => {});
    if (mode === 'settings') { settings(); return; }
    if (mode === 'project') {
      // Win + P (screen projection)
      keyChord(0x50, settings);
      return;
    }
    // Win + K: the Windows "Connect" panel (wireless displays, Miracast TVs)
    keyChord(0x4B, settings);
  });
  ipcMain.on('shell:ready', (e) => { e.returnValue = true; });
  // the site view asks which scripts to run before the page starts
  ipcMain.on('site:cfg', (e) => {
    const st = siteState;
    let js = '';
    if (st && e.sender.id === st.view.webContents.id) {
      const parts = [];
      if (st.prof.pre) parts.push(st.prof.pre);
      const onDir = st.prof.directory && st.curBase === st.prof.directory;
      if (!(st.prof.name === 'Your SPACE' && onDir) && st.blocking && st.relax < 1) parts.push(st.prof.pageJs);
      js = parts.join('\n');
    }
    e.returnValue = js;
  });
}

// ---------------------------------------------------------------------------------------------
app.whenReady().then(() => {
  try {
    // encrypted DNS: sites that are blocked by name at the provider open normally
    app.configureHostResolver({
      secureDnsMode: 'automatic',
      secureDnsServers: ['https://cloudflare-dns.com/dns-query', 'https://dns.google/dns-query'],
    });
  } catch (e) { /* older system: normal DNS */ }
  configureShellSession();
  setupIpc();
  createWindow();
  app.on('activate', () => { if (!BrowserWindow.getAllWindows().length) createWindow(); });
});
app.on('second-instance', () => { if (win) { if (win.isMinimized()) win.restore(); win.focus(); } });
app.on('window-all-closed', () => { app.quit(); });
