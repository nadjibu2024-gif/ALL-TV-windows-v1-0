@echo off
chcp 65001 >nul
setlocal EnableExtensions
title All TV - Build for Windows 10 x64
set "SRC=%~dp0"
set "WORK=C:\AllTV-build"
where node >nul 2>nul
if errorlevel 1 (
  echo Node.js is not installed. Install the LTS version from https://nodejs.org then run this file again.
  pause
  exit /b 1
)
echo [1/5] Copying the project to %WORK% ^(Desktop and OneDrive folders are protected by Windows and can break the build^)...
if exist "%WORK%\dist" rmdir /s /q "%WORK%\dist"
if exist "%WORK%\.cache" rmdir /s /q "%WORK%\.cache"
robocopy "%SRC%." "%WORK%" /E /XD node_modules dist .cache /NFL /NDL /NJH /NJS /NP >nul
cd /d "%WORK%"
if exist node_modules\electron rmdir /s /q node_modules\electron
set "ELECTRON_CACHE=%WORK%\.cache\electron"
set "ELECTRON_BUILDER_CACHE=%WORK%\.cache\builder"
echo [2/5] Installing packages ^(needs internet^)...
call npm install --foreground-scripts
if errorlevel 1 ( echo npm install failed & pause & exit /b 1 )
echo [3/5] Downloading Electron with Windows curl ^(about 115 MB, please wait^)...
set "VER=33.2.1"
set "ZIP=%WORK%\electron-%VER%.zip"
set "DIST=%WORK%\node_modules\electron\dist"
if exist "%DIST%" rmdir /s /q "%DIST%"
mkdir "%DIST%"
if exist "%ZIP%" del /q "%ZIP%"
curl.exe -L --retry 3 --fail -o "%ZIP%" "https://github.com/electron/electron/releases/download/v%VER%/electron-v%VER%-win32-x64.zip"
call :size
if %ZSIZE% LSS 100000000 (
  echo GitHub download failed or incomplete ^(size %ZSIZE%^), trying a mirror...
  curl.exe -L --retry 3 --fail -o "%ZIP%" "https://registry.npmmirror.com/-/binary/electron/v%VER%/electron-v%VER%-win32-x64.zip"
  call :size
)
echo Downloaded size: %ZSIZE% bytes ^(should be about 115000000^)
if %ZSIZE% LSS 100000000 (
  echo ERROR: the download is incomplete. Check your internet connection, then run again.
  pause
  exit /b 1
)
echo Extracting...
tar.exe -xf "%ZIP%" -C "%DIST%"
if not exist "%DIST%\electron.exe" (
  echo ERROR: electron.exe was NOT created when extracting. Something blocks writing files in C:\AllTV-build.
  dir "%DIST%"
  pause
  exit /b 1
)
echo electron.exe extracted OK. Waiting 8 seconds to see if an antivirus deletes it...
timeout /t 8 /nobreak >nul
if not exist "%DIST%\electron.exe" (
  echo.
  echo ERROR: electron.exe was DELETED by your antivirus a few seconds after extraction.
  echo Open Windows Security ^> Virus and threat protection ^> Protection history, restore electron.exe,
  echo add C:\AllTV-build to Exclusions ^(also in any other antivirus you use^), then run this file again.
  pause
  exit /b 1
)
> "%WORK%\node_modules\electron\path.txt" <nul set /p "=electron.exe"
echo Electron is ready.
echo [4/5] Building the installer and the portable program...
call npm run dist
if errorlevel 1 (
  echo.
  echo Build failed. Send a photo of the red text above.
  pause
  exit /b 1
)
echo [5/5] Copying the programs to your Desktop...
set "DESK=%USERPROFILE%\Desktop"
if not exist "%DESK%" set "DESK=%USERPROFILE%\OneDrive\Desktop"
copy /y dist\*.exe "%DESK%\" >nul
echo.
echo DONE. Files are in "%WORK%\dist" and on your Desktop:
dir /b dist\*.exe
explorer "%WORK%\dist"
pause
exit /b 0
:size
set "ZSIZE=0"
if exist "%ZIP%" for %%F in ("%ZIP%") do set "ZSIZE=%%~zF"
exit /b 0
