@echo off
chcp 65001 >nul
cd /d "%~dp0"
call npm install
if not exist node_modules\electron\dist\electron.exe node node_modules\electron\install.js
call npm start
